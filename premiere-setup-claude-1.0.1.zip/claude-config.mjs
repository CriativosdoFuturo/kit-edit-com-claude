// Registro do MCP no Claude Code (app desktop e terminal).
// O Claude Code guarda os MCPs de usuário em ~/.claude.json (ou $CLAUDE_CONFIG_DIR/.claude.json).
// Aqui só mexemos na chave mcpServers[<nome>]; o resto do arquivo fica como estava.
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';

export function claudeConfigFile(override) {
 if (override) return path.resolve(override);
 if (process.env.CLAUDE_CONFIG_DIR) return path.join(process.env.CLAUDE_CONFIG_DIR, '.claude.json');
 return path.join(os.homedir(), '.claude.json');
}

function readConfig(file) {
 if (!fs.existsSync(file)) return {};
 const text = fs.readFileSync(file, 'utf8');
 if (!text.trim()) return {};
 try { return JSON.parse(text); }
 catch (e) { throw new Error('CLAUDE_CONFIG_INVALID: ' + file + ' nao e um JSON valido; nada foi alterado. (' + e.message + ')'); }
}

export function getServer(file, name) {
 const cfg = readConfig(file);
 return cfg.mcpServers && Object.prototype.hasOwnProperty.call(cfg.mcpServers, name) ? cfg.mcpServers[name] : null;
}

export function backupConfig(file, backup) {
 if (!fs.existsSync(file)) return null;
 fs.mkdirSync(path.dirname(backup), { recursive: true });
 fs.copyFileSync(file, backup, fs.constants.COPYFILE_EXCL);
 return backup;
}

// Troca o nome de uma entrada (mantém a configuração dela). Atômico e conferido, como registerServer.
export async function renameServer(file, from, to, { waitMs = 3000 } = {}) {
 for (let attempt = 1; attempt <= 2; attempt++) {
  const cfg = readConfig(file);
  const entry = cfg.mcpServers?.[from];
  if (!entry) break;
  cfg.mcpServers[to] = entry;
  delete cfg.mcpServers[from];
  const tmp = file + '.tmp-' + crypto.randomUUID();
  fs.writeFileSync(tmp, JSON.stringify(cfg, null, 2), { flag: 'wx' });
  fs.renameSync(tmp, file);
  await new Promise(r => setTimeout(r, waitMs));
  if (getServer(file, to) && !getServer(file, from)) return getServer(file, to);
 }
 throw new Error('CLAUDE_CONFIG_NOT_CONFIRMED: a troca de nome de ' + from + ' para ' + to + ' nao ficou salva em ' + file + '. Encaminhe ao suporte. Backup preservado.');
}

// Grava de forma atômica (arquivo temporário na mesma pasta + rename) e confere depois.
export async function registerServer(file, name, entry, { waitMs = 3000 } = {}) {
 for (let attempt = 1; attempt <= 2; attempt++) {
  const cfg = readConfig(file);
  if (!cfg.mcpServers || typeof cfg.mcpServers !== 'object') cfg.mcpServers = {};
  cfg.mcpServers[name] = entry;
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const tmp = file + '.tmp-' + crypto.randomUUID();
  fs.writeFileSync(tmp, JSON.stringify(cfg, null, 2), { flag: 'wx' });
  fs.renameSync(tmp, file);
  // O app do Claude também grava esse arquivo; espera um pouco e confere se o registro ficou.
  await new Promise(r => setTimeout(r, waitMs));
  const saved = getServer(file, name);
  if (saved && saved.command === entry.command && JSON.stringify(saved.args) === JSON.stringify(entry.args)) return saved;
 }
 throw new Error('CLAUDE_CONFIG_NOT_CONFIRMED: o registro nao ficou salvo em ' + file + '. Repita somente o registro com install.mjs --register-existing. Se continuar, encaminhe ao suporte. Backup preservado.');
}
