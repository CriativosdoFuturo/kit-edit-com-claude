import fs from 'node:fs';
import {enableSystemCA,checkSpace} from './environment-checks.mjs';
import fsp from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';
import {pipeline} from 'node:stream/promises';
import {Readable} from 'node:stream';
import {createGunzip} from 'node:zlib';
import {fileURLToPath} from 'node:url';
import {checkWindowsIdentity,checkWritableDirectory,checkExistingConfig,checkWindowsRegistryAccess} from './preflight.mjs';
import {validatePartialInstallation} from './recovery.mjs';
import {claudeConfigFile,getServer,backupConfig,registerServer,renameServer} from './claude-config.mjs';

const here=path.dirname(fileURLToPath(import.meta.url));
const win=process.platform==='win32';
const args=process.argv.slice(2);
const resume=args.includes('--resume');
const registerExisting=args.includes('--register-existing');
const arg=(key,fallback)=>args.includes(key)?args[args.indexOf(key)+1]:fallback;
const root=path.resolve(arg('--root',win?path.join(process.env.LOCALAPPDATA,'CriativosdoFuturo','PremiereMCP'):path.join(os.homedir(),'Library/Application Support/CriativosdoFuturo/PremiereMCP')));
const manifest=JSON.parse(fs.readFileSync(path.join(here,'kit-manifest.json'),'utf8'));
const app=path.join(root,'app');
const tools=path.join(root,'tools');
const cep=win?path.join(process.env.APPDATA,'Adobe/CEP/extensions/MCPBridgeCEP'):path.join(os.homedir(),'Library/Application Support/Adobe/CEP/extensions/MCPBridgeCEP');
const bridge=win?path.join(os.tmpdir(),'premiere-mcp-bridge'):'/tmp/premiere-mcp-bridge';
const config=claudeConfigFile(arg('--claude-config'));
const serverName='trombs-premiere';
const legacyName='premiere_pro_trombino'; // nome usado ate claude-1.0.0
const run=(exe,params)=>{
 const r=spawnSync(exe,params,{encoding:'utf8',windowsHide:true,timeout:600000});
 if(r.error||r.status!==0) throw new Error(`${path.basename(exe)} falhou (${r.status}): ${r.error?.message||r.stderr?.slice(-1500)||r.stdout?.slice(-1500)}`);
 return r.stdout;
};
const sha=async(file)=>{const h=crypto.createHash('sha256'); for await(const b of fs.createReadStream(file))h.update(b);return h.digest('hex');};
async function download(url,dest,hash){
 if(fs.existsSync(dest)&&await sha(dest)===hash)return;
 const partial=dest+'.partial-'+crypto.randomUUID();
 console.log('Baixando '+path.basename(dest));
 let res;
 try {res=await fetch(url,{signal:AbortSignal.timeout(900000)});}
 catch(e){throw new Error('DOWNLOAD_FAILED: '+url+'; '+(e.cause?.code||e.code||e.message)+'. Verifique certificados do sistema, rede e proxy; nao desative TLS.');}
 if(!res.ok)throw new Error('Download HTTP '+res.status+' de '+url);
 await pipeline(Readable.fromWeb(res.body),fs.createWriteStream(partial,{flags:'wx'}));
 if(await sha(partial)!==hash)throw new Error('Integridade divergente: '+partial+'; nada foi executado.');
 await fsp.rename(partial,dest);
}
const entryFor=(node,cli,env)=>({type:'stdio',command:node,args:[cli],env});
const norm=p=>{const r=path.resolve(String(p));return win?r.toLowerCase():r;};
// A entrada aponta para o servidor desta instalacao (pasta root)?
const isOurEntry=e=>Array.isArray(e?.args)&&e.args.length>0&&norm(e.args[0]).startsWith(norm(root)+path.sep);
const NEXT='No Claude, abra uma CONVERSA NOVA (o MCP aparece nas conversas novas). No Premiere, abra seu projeto antes de Janela > Extensoes > MCP Bridge. Nenhuma edicao de teste necessaria.';

// Ja existe uma instalacao do Premiere neste computador (por exemplo, do curso anterior):
// so registra no Claude, sem baixar nem copiar nada de novo.
async function registerExistingInstallation(){
 const state=JSON.parse(fs.readFileSync(path.join(root,'installation.json'),'utf8'));
 for(const k of ['node','cli'])if(!state[k]||!fs.existsSync(state[k]))throw new Error('EXISTING_INSTALLATION_INCOMPLETE: '+k+' ausente em '+(state[k]||root)+'. Rode doctor.mjs e diagnostique; nao apague pastas.');
 checkWritableDirectory(path.dirname(config));
 const backup=backupConfig(config,path.join(root,'logs','claude-config-before-'+crypto.randomUUID()+'.json'));
 await registerServer(config,serverName,entryFor(state.node,state.cli,state.env||{}));
 console.log('REGISTRADO_NO_CLAUDE: instalacao existente reaproveitada; nada foi baixado nem substituido.'+(backup?' Backup: '+backup:''));
 console.log('Proxima etapa: '+path.join(root,win?'runtime/node.exe':'runtime/node')+' '+path.join(root,'connection.mjs')+' --connect (somente leitura). '+NEXT);
}

async function main(){
 if(!['win32','darwin'].includes(process.platform))throw new Error('Execute no computador Windows ou Mac onde o Premiere esta instalado.');
 if(Number(process.versions.node.split('.')[0])<20)throw new Error('Node 20+ necessario.');
 if(!['x64','arm64'].includes(process.arch))throw new Error('Arquitetura nao suportada.');
 checkWindowsIdentity();
 enableSystemCA();
 if(win)run('tar.exe',['--version']);
 checkExistingConfig(config);
 // Instalacao do curso feita com o nome antigo: so troca o nome da entrada (com backup).
 // Um MCP com o nome antigo que nao aponta para esta instalacao nao e tocado.
 const legacy=getServer(config,legacyName);
 if(legacy&&!getServer(config,serverName)&&isOurEntry(legacy)){
  checkWritableDirectory(path.dirname(config));
  const backup=backupConfig(config,path.join(root,'logs','claude-config-before-rename-'+crypto.randomUUID()+'.json'));
  await renameServer(config,legacyName,serverName);
  console.log('RENOMEADO_NO_CLAUDE: o MCP do curso agora se chama '+serverName+' (antes '+legacyName+').'+(backup?' Backup: '+backup:''));
 }
 const existing=getServer(config,serverName);
 if(fs.existsSync(path.join(root,'installation.json'))){
  if(existing){console.log('Instalacao existente e ja registrada no Claude. Execute doctor.mjs e connection.mjs --connect na pasta '+root+'; nao reinstale.');return;}
  if(registerExisting)return registerExistingInstallation();
  console.log('EXISTING_INSTALLATION_NOT_IN_CLAUDE: o Premiere MCP ja esta instalado em '+root+' (provavelmente de um curso anterior), mas ainda nao esta ligado ao Claude. Para ligar sem reinstalar, rode: node install.mjs --register-existing'+(arg('--root')?' --root "'+root+'"':'')+' . Nada foi alterado.');
  process.exitCode=3;return;
 }
 if(registerExisting)throw new Error('NO_EXISTING_INSTALLATION: nao ha installation.json em '+root+'. Rode a instalacao normal, sem --register-existing.');
 if(resume){
  if(!win||args.includes('--prepare-only')||existing)throw new Error('RECOVERY_REFUSED: recuperacao limitada a Windows, dependencias completas e MCP ainda nao registrado. Preserve e diagnostique.');
  console.log(JSON.stringify(await validatePartialInstallation({root,app,cep,here,manifest})));
 }else if(existing)throw new Error('EXISTING_MCP: o Claude ja tem um MCP chamado '+serverName+' em '+config+'. Teste se ele funciona antes de qualquer coisa; se funcionar, use-o. Nada foi alterado.');
 else if(fs.existsSync(app)||fs.existsSync(cep))throw new Error('EXISTING_INSTALLATION: preservado. Se a instalacao ficou incompleta antes do registro MCP, leia COMO-CONDUZIR.txt e avalie --resume --preflight; nao apague nem substitua os arquivos.');
 for(const target of [root,path.dirname(cep),path.dirname(config),bridge])checkWritableDirectory(target);
 if(!args.includes('--prepare-only'))checkWindowsRegistryAccess();
 checkSpace([{path:root,bytes:2n*1024n**3n},{path:path.dirname(cep),bytes:128n*1024n**2n},{path:path.dirname(config),bytes:16n*1024n**2n},{path:bridge,bytes:64n*1024n**2n}]);
 if(args.includes('--preflight')){console.log('PRECHECK_OK: identidade, arquivos, configuracao do Claude ('+config+') e acesso ao Registro (Windows) conferidos; nada foi alterado. Instalacao e conexao ainda nao executadas.');return;}
 fs.mkdirSync(root,{recursive:true});
 const lock=path.join(root,'install.lock');
 const handle=fs.openSync(lock,'wx');fs.closeSync(handle);
 try {
  for(const p of ['downloads','tools','models','transcripts','logs'])fs.mkdirSync(path.join(root,p),{recursive:true});
  const downloads=path.join(root,'downloads');
  const node=path.join(root,win?'runtime/node.exe':'runtime/node');
  let ffmpeg=path.join(tools,'ffmpeg.exe'),whisper=path.join(tools,'whisper-cli.exe');
  const model=path.join(root,'models',manifest.model.name);
  const cli=path.join(app,'node_modules/adobe-premiere-pro-mcp/dist/index.js');
  if(!resume){
  fs.mkdirSync(path.dirname(node),{recursive:true});
  if(!fs.existsSync(node))fs.copyFileSync(process.execPath,node,fs.constants.COPYFILE_EXCL);
  if(!win)fs.chmodSync(node,0o755);
  run(node,['--version']);
  if(win){
   ffmpeg=path.join(tools,'ffmpeg.exe');whisper=path.join(tools,'whisper-cli.exe');
   const gz=path.join(downloads,'ffmpeg.gz');
   await download('https://github.com/eugeneware/ffmpeg-static/releases/download/b6.1.1/ffmpeg-win32-x64.gz',gz,manifest.ffmpeg['win-x64']);
   if(!fs.existsSync(ffmpeg))await pipeline(fs.createReadStream(gz),createGunzip(),fs.createWriteStream(ffmpeg,{flags:'wx'}));
   const asset=process.arch==='arm64'?'whisper-bin-win-cpu-arm64.zip':'whisper-bin-x64.zip';
   const zip=path.join(downloads,asset);
   await download(`https://github.com/ggml-org/whisper.cpp/releases/download/${manifest.whisper.windowsRelease}/${asset}`,zip,manifest.whisper['win-'+process.arch]);
   const extract=path.join(downloads,'whisper-'+crypto.randomUUID());
   fs.mkdirSync(extract);
   run('tar.exe',['-xf',zip,'-C',extract]);
   function find(dir){for(const ent of fs.readdirSync(dir,{withFileTypes:true})){const f=path.join(dir,ent.name);if(ent.isDirectory()){const found=find(f);if(found)return found;}else if(ent.name==='whisper-cli.exe')return f;}}
   const found=find(extract);if(!found)throw new Error('whisper-cli.exe ausente no pacote oficial.');
   for(const ent of fs.readdirSync(path.dirname(found),{withFileTypes:true}))if(ent.isFile()&&!fs.existsSync(path.join(tools,ent.name)))fs.copyFileSync(path.join(path.dirname(found),ent.name),path.join(tools,ent.name),fs.constants.COPYFILE_EXCL);
  } else {
   const brew=['/opt/homebrew/bin/brew','/usr/local/bin/brew'].find(p=>fs.existsSync(p));
   if(!brew)throw new Error('HOMEBREW_REQUIRED: instalar Homebrew pela fonte oficial e retomar. Nao foi executado script remoto.');
   for(const pkg of ['ffmpeg','whisper-cpp']){
    const r=spawnSync(brew,['list',pkg],{encoding:'utf8'});if(r.status!==0)run(brew,['install',pkg]);
   }
   const prefix=run(brew,['--prefix']).trim();ffmpeg=path.join(prefix,'bin/ffmpeg');whisper=path.join(prefix,'bin/whisper-cli');
  }
  run(ffmpeg,['-version']);run(whisper,['--help']);
  await download('https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-small.bin',model,manifest.model.sha256);
  fs.cpSync(path.join(here,'vendor'),app,{recursive:true,errorOnExist:true,force:false});
  if(args.includes('--prepare-only')){
   fs.writeFileSync(path.join(root,'assets-prepared.json'),JSON.stringify({node,cli,ffmpeg,whisper,model,modelSha256:manifest.model.sha256,hostConfigured:false},null,2));
   console.log('DEPENDENCIAS_PREPARADAS: sem painel instalado nem configuracao alterada.');return;
  }
  const panelSource=path.join(app,'node_modules/adobe-premiere-pro-mcp/cep-plugin');
  fs.mkdirSync(path.dirname(cep),{recursive:true});
  fs.cpSync(panelSource,cep,{recursive:true,errorOnExist:true,force:false});
  }
  // O painel CEP local precisa de PlayerDebugMode. Proteções do sistema continuam iguais.
  const registry=[];
  for(let v=9;v<=15;v++){
   if(win){
    const key=`HKCU\\Software\\Adobe\\CSXS.${v}`;
    const previous=spawnSync('reg.exe',['query',key,'/v','PlayerDebugMode'],{encoding:'utf8',windowsHide:true});
    registry.push({key,previous:previous.stdout||'',status:previous.status});
   } else {
    const key=`com.adobe.CSXS.${v}`;const previous=spawnSync('defaults',['read',key,'PlayerDebugMode'],{encoding:'utf8'});
    registry.push({key,previous:previous.stdout||'',status:previous.status});
   }
  }
  const registryBackup=path.join(root,resume?'cep-settings-recovery-'+crypto.randomUUID()+'.json':'cep-settings-before.json');
  fs.writeFileSync(registryBackup,JSON.stringify(registry,null,2),{flag:'wx'});
  for(const {key} of registry)win?run('reg.exe',['add',key,'/v','PlayerDebugMode','/t','REG_SZ','/d','1','/f']):run('defaults',['write',key,'PlayerDebugMode','1']);
  fs.mkdirSync(bridge,{recursive:true});
  const backup=backupConfig(config,path.join(root,'logs',resume?'claude-config-recovery-'+crypto.randomUUID()+'.json':'claude-config-before.json'));
  const env={PREMIERE_TEMP_DIR:bridge,PREMIERE_MCP_TELEMETRY:'0',PREMIERE_MCP_UPDATE_CHECK:'0',PREMIERE_MCP_TOOLSET:'search',PREMIERE_MCP_FFMPEG:ffmpeg,PREMIERE_MCP_WHISPER:whisper,PREMIERE_MCP_WHISPER_MODEL:model,PREMIERE_MCP_TRANSCRIPT_DIR:path.join(root,'transcripts')};
  await registerServer(config,serverName,entryFor(node,cli,env));
  for(const name of ['doctor.mjs','connection.mjs'])fs.copyFileSync(path.join(here,name),path.join(root,name),fs.constants.COPYFILE_EXCL);
  const state={version:manifest.kitVersion,client:'claude',claudeConfig:config,claudeConfigBackup:backup,node,cli,ffmpeg,whisper,model,modelSha256:manifest.model.sha256,cep,bridge,env,installedAt:new Date().toISOString(),connectionVerified:false};
  fs.writeFileSync(path.join(root,'installation.json'),JSON.stringify(state,null,2),{flag:'wx'});
  console.log(run(node,[path.join(root,'doctor.mjs')]));
  console.log('INSTALADO. Proxima etapa: connection.mjs --connect (somente leitura). '+NEXT);
 }finally{fs.unlinkSync(lock);}
}
main().catch(e=>{console.error('INSTALACAO INTERROMPIDA: '+e.message);console.error('Preparacao incompleta. Preserve os arquivos e diagnostique a etapa antes de repetir.');process.exitCode=1;});
