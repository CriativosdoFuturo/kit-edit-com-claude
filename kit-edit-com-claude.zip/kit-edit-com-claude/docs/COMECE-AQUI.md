# Kit Edit com Claude Code — seu caminho de edição

Versão 3.0.0 — Edit com Claude Code (rascunho de 30/10/2026).

## Antes de tudo

1. Extraia o ZIP.
2. Abra o app do Claude no computador, entre na aba **Code** e selecione a pasta extraída.
3. Cole o pedido de preparação que está no [README](../README.md).
4. Quando o teste de 8 segundos terminar, abra uma nova sessão no Claude Code, na mesma pasta, para editar.

Conectar o editor: em preparação. Por enquanto, o MCP do Premiere é instalado à parte.

## Na sessão de edição

Comece dizendo: **“Use a skill Trombino para me ajudar a editar este vídeo.”**

O Claude aproveita as informações que você já passou e pergunta o que faltar:

1. Você vai continuar no Premiere, DaVinci ou CapCut, ou quer receber o vídeo pronto?
2. Quer artes para importar, uma montagem completa ou elementos editáveis dentro do editor?
3. Qual vídeo/trecho, formato e referência devemos usar?

Para limpar a fala de uma gravação (erros, tentativas, repetições, falas de bastidor e pausas), o Claude usa a skill **decupagem-pt** e entrega uma sequência nova para o Premiere.

## Três maneiras de trabalhar

**Artes para o seu editor.** O Claude cria um lettering, gráfico ou insert animado. Você recebe os arquivos separados, com fundo transparente, para colocar sobre sua edição. Se houver uma integração conectada e testada, o Claude também pode colocá-los na timeline. Um render não vira automaticamente texto editável no editor.

**Edição dentro do programa.** O Claude precisa de acesso específico ao editor. No Premiere, isso é uma integração separada do HyperFrames. DaVinci e CapCut precisam de suas próprias verificações. Instalar este kit não conecta os três programas.

**Vídeo pronto por conversa.** Você fornece mídia, roteiro e referências. O Claude cria a composição; HyperFrames renderiza o vídeo. Você revisa a prévia, pede ajustes e recebe um MP4. O Studio é a interface local de prévia e ajustes da composição, não um serviço onde é obrigatório enviar o vídeo.

“Sem editor” significa sem operar Premiere, Resolve ou CapCut. Ainda existe software rodando no seu computador: Claude Code, HyperFrames, navegador e FFmpeg. No Chat do Claude, ele trabalha num computador dele na nuvem e devolve arquivos; no Code, ele trabalha no seu computador. Este kit é para o Code.

## O método ensinado no curso

Entender o resultado → analisar/transcrever quando necessário → escolher as falas → montar → planejar as artes no tempo certo → renderizar → assistir e corrigir.

Para uma arte isolada, podemos começar diretamente pelo briefing visual. Para vídeo falado, uma transcrição com tempos ajuda no sincronismo. Serviços externos de geração de imagens, vídeo ou música são opcionais e podem ter custo próprio. O kit não inclui créditos nem chaves de API.

## O que há nas skills

São 16 skills. As 14 da base cobrem edição, cortes, narrativa, estilos, animação, prévia e exportação. A skill **trombino** é a entrada do curso e escolhe o caminho de entrega. A skill **decupagem-pt** limpa a fala em português. São instruções e, em alguns casos, scripts auxiliares; não são treinamento do modelo nem conexões automáticas com aplicativos.

O motor e a base didática são projetos de terceiros adaptados para este curso. As licenças e os créditos estão preservados em LICENSE e THIRD_PARTY_NOTICES.md.
