# Instalação e primeiro teste

Este é um kit de projeto, não um instalador universal. O jeito recomendado é pedir ao Claude Code que siga o [INSTALAR.md](../INSTALAR.md). Esta página resume o que ele faz.

## Dependências

- Node 22+ e npm: https://nodejs.org/en/download
- FFmpeg e ffprobe disponíveis no PATH: https://ffmpeg.org/download.html
- Python 3.10+ (para a decupagem de fala): https://www.python.org/downloads/

Na pasta extraída, depois de conferir essas dependências:

```sh
npm ci
npm run setup
npx hyperframes browser ensure
npm run check
npm run new-video -- primeiro-teste
npx hyperframes render video-projects/primeiro-teste --output renders/primeiro-teste.mp4 --quality draft --workers 1
```

`npx hyperframes browser ensure` baixa o navegador usado no render (Chrome Headless Shell). Se o renderizador ainda não localizar o navegador, peça ao Claude que verifique o Chrome instalado e configure HYPERFRAMES_BROWSER_PATH para aquele executável na sessão. Não copie caminhos de outro computador. O teste não usa API paga nem contém fala; deve gerar um vídeo de oito segundos com texto e cards.

O ambiente da decupagem (`.venv` na raiz do kit) é criado conforme `.claude/skills/decupagem-pt/SKILL.md`. Na primeira decupagem, os modelos de transcrição são baixados (cerca de 3 GB).

Não desative verificações TLS nem altere permanentemente políticas do computador para contornar erros. Informe a mensagem ao assistente para diagnóstico específico.

## Depois do teste

Encerre a sessão de instalação e abra uma nova sessão no Claude Code, na mesma pasta, antes da primeira edição real. Isso evita carregar de novo logs de dependências, testes e catálogos de ferramentas em cada operação do editor. Na nova sessão, peça a entrega desejada usando a skill trombino. Para limpar uma gravação de fala, use a skill decupagem-pt. Leia [Decupagem segura e econômica](DECUPAGEM-SEGURA.md).

## Conectar o editor

Cada editor tem o seu MCP, instalado à parte (aula 03):

- **Premiere (Windows e Mac):** https://github.com/CriativosdoFuturo/kit-edit-com-claude/blob/main/INSTALAR-PREMIERE.md. O MCP se chama `premiere_pro_trombino`.
- **DaVinci Resolve:** https://github.com/samuelgursky/davinci-resolve-mcp
- **CapCut Windows:** https://github.com/yabdulaziz2009-dev/capcut-mcp
- **CapCut Mac:** https://github.com/drhema/mcp-cut
- **Final Cut Pro (Mac):** https://github.com/DareDev256/fcp-mcp-server

Os MCPs de DaVinci, CapCut e Final Cut são projetos de terceiros e não foram testados com o Claude neste curso. Uma conexão ativa não comprova suporte a todos os efeitos.
