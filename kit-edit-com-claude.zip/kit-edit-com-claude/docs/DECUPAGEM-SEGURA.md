# Decupagem segura e econômica

Use este fluxo para limpar vídeo falado em português e levar o resultado ao Premiere. A limpeza de fala (erros, tentativas, repetições, falas de bastidor e pausas) é feita pela skill `decupagem-pt`. Ele reduz repetição, protege a sequência original e evita que a interface seja operada clique por clique sem necessidade.

## Antes de começar

- Termine instalação, diagnóstico e teste sintético na sessão de preparação.
- Abra uma nova sessão no Claude Code, na mesma pasta, para a edição real.
- Informe somente o caminho da mídia, o projeto do editor, a sequência e o resultado desejado.
- Trabalhe sempre numa sequência nova. Nunca mexa na sequência original nem em versões anteriores. Preserve bruto, transcrição e versões anteriores.
- Use somente a integração do editor necessária. No Premiere, o MCP se chama `premiere_pro_trombino`. Não carregue catálogos de animação numa etapa de cortes.

## Fluxo da decupagem

1. Copie o vídeo para `video-projects/<nome>/` e rode a skill `decupagem-pt` (ela nunca altera o arquivo de entrada). Para testar ajustes, reutilize a transcrição anterior em vez de transcrever de novo.
2. Leia o resultado da conferência e as imagens das emendas.
3. Casos duvidosos ficam com as duas versões, marcados para o aluno escolher. Falas de bastidor saem.
4. No Premiere, confira qual projeto está ativo antes de importar: o aluno pode ter outros projetos abertos.
5. Importe o `decupagem.xml` nesse projeto. Ele cria uma sequência nova com data e hora no nome.
6. Confira palavras nas bordas, sincronismo, respirações longas e duração final.
7. Não salve o projeto sem o aluno pedir. Relate somente as decisões e limitações relevantes: duração antes e depois, o que foi cortado, os duvidosos e os alertas.

## Corte apertado e J-cut

São operações relacionadas, mas diferentes:

- **Corte apertado de diálogo:** elimina pausa morta, hesitação e respiração indesejada entre falas. A última sílaba permanece inteira e a próxima fala começa imediatamente depois, com o espaço mínimo que preserve naturalidade.
- **J-cut verdadeiro:** além de apertar o diálogo, o áudio do próximo trecho começa antes da troca para a imagem correspondente. A imagem anterior permanece por alguns frames enquanto a próxima fala já é ouvida.

Quando o usuário pedir apenas para decupar, limpar ou deixar o vídeo dinâmico, faça o corte apertado como padrão. Use J-cuts nas junções em que a antecipação de áudio melhorar a continuidade. Quando o usuário pedir J-cuts explicitamente, trate a antecipação do áudio como requisito e não entregue apenas cortes secos alinhados.

Para cada junção:

1. use o timestamp da transcrição apenas para localizar a borda; ele não comprova onde o som da palavra termina;
2. preserve completamente a última sílaba e o fonema final da fala anterior, incluindo o “s” de palavras como “professores”, antes de cortar o respiro;
3. procure alguns frames depois do fim marcado e escute consoantes finais de baixa energia, como `/s/`, `/ʃ/`, `/f/`, `/v/`, `/r/`, nasais e a soltura de consoantes oclusivas; detectores simples de silêncio podem confundi-las com ruído ou silêncio;
4. mantenha uma margem fonética conservadora quando só houver timestamps; o cortador local usa 160 ms por padrão, mas a escuta do áudio prevalece sobre esse número;
5. posicione o corte depois do fonema completo e antes da parte removível do respiro; não use crossfade para esconder uma letra já cortada;
6. retire pausas longas e respirações indesejadas, preservando respirações expressivas ou necessárias;
7. feche primeiro o ritmo do diálogo, sem sobrepor palavras inteligíveis;
8. antecipe o início do áudio seguinte sob a imagem anterior, normalmente por poucos frames e conforme a cadência, em vez de usar um valor fixo em todas as junções;
9. use outra faixa de áudio ou handles suficientes quando a timeline exigir sobreposição;
10. aplique uma transição de áudio curta somente quando houver material adequado e ela não apagar consoantes;
11. confira pela forma de onda e, obrigatoriamente, pela escuta em velocidade normal; reduza a velocidade nos finais duvidosos;
12. se houver dúvida entre fonema e respiro, preserve mais áudio e ajuste depois de ouvir;
13. confirme que a fronteira de vídeo e a fronteira do áudio não permanecem todas alinhadas quando a intenção for um J-cut.

Em talking head de uma única câmera, antecipar muito a voz enquanto a boca anterior continua visível pode parecer dessincronizado. Nesses casos, encurte a antecipação ou cubra a passagem com punch-in, outro ângulo, reação, mãos, tela ou B-roll. Se não houver cobertura segura, entregue um corte apertado em vez de fabricar um J-cut visualmente errado e explique a limitação.

## Modos de execução

### Modo econômico — padrão

Use sempre que o usuário não pedir outra experiência. Aplique a lista em lote ou no menor número de lotes possível e faça uma revisão final. Este é o modo recomendado para reduzir chamadas, tempo e consumo dos limites de uso do plano do Claude.

### Demonstração visual — somente quando solicitada

Use em aulas ou quando a pessoa quiser acompanhar o Premiere, DaVinci ou CapCut trabalhando. O Claude cria a lista inteira uma única vez e então executa os cortes em ordem, um por um. Cada passo reaproveita o plano fechado e retorna somente um resultado curto. Não volte a analisar o vídeo entre os cortes.

Antes de começar, o Claude deve explicar de forma breve: **“Beleza, vou fazer no modo demonstração visual para você acompanhar os cortes acontecendo. Só para você saber: isso costuma levar mais tempo e consumir mais dos limites de uso do seu plano do Claude do que aplicar tudo de uma vez, porque o editor executa cada corte separadamente. Como você pediu esse modo, vou seguir assim.”** O pedido do usuário já escolheu esse modo; depois do aviso, prossiga sem criar outra etapa de confirmação.

Esse modo demora um pouco mais porque o editor recebe mais operações, mas não deve multiplicar o raciocínio nem a transcrição. Não use pausas longas apenas para criar espetáculo. Alguns editores só atualizam a imagem depois de um pequeno grupo de comandos; nesse caso, use poucos blocos verificáveis.

## Limites de repetição

- Prefira o MCP do editor. Use controle visual apenas quando a integração não oferecer a operação necessária.
- Não faça uma nova consulta ao modelo para cada clipe.
- Não imprima todos os esquemas de ferramentas, árvores de acessibilidade ou estados completos da timeline.
- O limite se aplica à mesma ação pelo mesmo método, não à tarefa inteira nem ao objetivo pedido pelo usuário.
- Uma resposta como `There has been no change` significa apenas que a interface não apresentou progresso observável; não prova que a ação falhou. Faça uma verificação independente do estado.
- Se a ação for segura e idempotente, faça no máximo uma segunda tentativa do mesmo método. Se continuar sem evidência, pare de repetir esse método e mude para o MCP, outra inspeção ou outro caminho seguro.
- Para cortes, exclusões e outras ações que podem ser duplicadas, não repita às cegas. Leia primeiro o estado da timeline e só prossiga quando souber se a primeira ação foi aplicada.
- Continue perseguindo o objetivo da edição depois de trocar de método. Peça intervenção do usuário somente quando todos os caminhos disponíveis falharem, o estado estiver incerto ou prosseguir trouxer risco ao projeto.
- Uma operação longa sem progresso útil deve ser interrompida; não mantenha consultas de espera indefinidas.
- Consultas de uma operação longa com progresso confirmado seguem o tempo limite da própria operação e não contam como repetição sem mudança.
- Não retranscreva para corrigir idioma sem confirmar antes o arquivo já produzido e a configuração da próxima tentativa.

## Projetos em pastas sincronizadas

Google Drive, OneDrive e Dropbox podem sincronizar o arquivo do projeto enquanto o editor salva e provocar avisos de alteração externa ou conflitos de versão. Isso não prova que o serviço causou outros erros da edição.

Quando o arquivo do projeto estiver numa dessas pastas:

1. preserve o original sincronizado;
2. crie uma cópia local do arquivo do projeto para a sessão de edição;
3. mantenha os vínculos de mídia existentes quando funcionarem;
4. salve e feche o editor antes de copiar a nova versão de volta para a pasta sincronizada;
5. nunca use a sincronização como motivo para repetir cliques ou consultas sem progresso.

## Pedido para uma sessão nova

> Use a skill decupagem-pt neste vídeo: [caminho do vídeo]. Depois importe o resultado no meu projeto do Premiere numa sequência nova, conferindo antes qual projeto está ativo. Não mexa na sequência original e não salve o projeto. Me mostre os duvidosos e os alertas com o tempo de cada um.

Se quiser acompanhar a timeline sendo alterada, acrescente: **“Quero o modo demonstração visual, executando o plano já fechado em ordem, sem reanalisar entre os cortes.”**

O uso do Claude segue os limites de uso do seu plano. O kit não promete custo ou duração exatos. Modelo, raciocínio e velocidade são escolhas do usuário; não os altere automaticamente.
