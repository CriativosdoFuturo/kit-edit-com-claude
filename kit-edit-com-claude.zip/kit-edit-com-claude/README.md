# Kit Edit com Claude Code

Versão 3.0.0 — Edit com Claude Code (04/11/2026). Baseado no Kit Trombino 2.1.4.

Kit do curso **Edit com Claude Code**, do **Criativos do Futuro**. Ele traz as instruções e as ferramentas para o Claude Code limpar a fala das suas gravações, criar animações com HyperFrames e montar vídeos no seu computador.

## Comece aqui

O jeito mais fácil: na aba **Code** do app do Claude, mande o link abaixo junto com o prompt da aula 03. O Claude cria a pasta **Documentos\Edit com Claude**, baixa o kit e prepara tudo.

https://github.com/CriativosdoFuturo/kit-edit-com-claude/blob/main/INSTALAR.md

O passo a passo que o Claude segue está em [INSTALAR.md](INSTALAR.md): Parte 1 (kit, skills e decupagem), Parte 2 (HyperFrames, aula 06) e como atualizar o kit sem perder seus projetos.

**Baixou o ZIP manualmente?** Extraia, abra a pasta na aba Code e peça: "Siga o INSTALAR.md desta pasta, Parte 1, avisando que os arquivos já estão aqui."

**Conferir as skills:** abra uma conversa nova nesta pasta e digite **/**. Na lista, procure **/decupagem-pt**, **/trombino**, **/edit-video** e **/hyperframes**.

**Conectar o editor (MCP):** cada editor tem o seu link. Premiere: [INSTALAR-PREMIERE.md](https://github.com/CriativosdoFuturo/kit-edit-com-claude/blob/main/INSTALAR-PREMIERE.md). O MCP do Premiere se chama `premiere_pro_trombino`.

## Terminou a preparação? Abra uma nova sessão para editar

Não continue a primeira edição na conversa usada para preparar o kit. Logs, testes e descobertas de ferramentas deixam essa conversa grande, e cada ação no editor passa a consumir mais dos limites de uso do seu plano do Claude.

1. No Claude Code, abra uma nova sessão na mesma pasta.
2. Diga onde está o vídeo e qual é o projeto do editor.
3. Para limpar a fala de uma gravação, cole: **“Use a skill decupagem-pt neste vídeo: [caminho do vídeo]. Depois importe o resultado no meu projeto do Premiere numa sequência nova, conferindo antes qual projeto está ativo. Não mexa na sequência original e não salve o projeto. Me mostre os duvidosos e os alertas com o tempo de cada um.”**

Leia [Decupagem segura e econômica](docs/DECUPAGEM-SEGURA.md) antes da primeira edição conectada.

## O que você recebe

- 16 skills: as 14 da base, a skill de entrada `trombino` e a `decupagem-pt` (limpeza de fala em português com sequência nova para o Premiere).
- Biblioteca de 406 cards em HTML/CSS/animação, em estágio de rascunho: pontos de partida para adaptar e revisar.
- 50 referências extras para adaptação. Elas não são 50 efeitos já prontos ou testados; consulte o catálogo só quando precisar.
- Templates de cenas, scripts de edição e exemplos sintéticos.
- Instruções para descobrir o método de cada aluno, sem impor o perfil pessoal do professor.
- Motor HyperFrames instalado como dependência, com versões fixadas pelo package-lock.json.

Leia [COMECE-AQUI](docs/COMECE-AQUI.md) e [instalação e teste](docs/INSTALACAO-TROMBINO.md).

## Escolha sua entrega

**Vídeo pronto:** composição e render local pelo HyperFrames, preservando o código-fonte.

**Artes para importar:** animações separadas para usar no seu editor, com fundo transparente; confira a transparência depois de importar.

**Projeto nativo:** depende da integração com o editor. Um vídeo renderizado não se transforma em texto, efeitos e keyframes nativos. Instalar o kit não instala os MCPs.

## Custos e limites

O kit não cobra assinatura própria. O motor tem sua licença de código aberto. O uso do Claude Code segue o plano e os limites de uso da sua conta do Claude; seu editor pode exigir licença. A decupagem-pt roda no seu computador e baixa os modelos de transcrição na primeira vez (cerca de 3 GB). Geração de mídia e outros serviços externos podem ter custos e não são necessários para o teste. O script de transcrição herdado (`npm run transcribe`) usa ElevenLabs: ele não é uma transcrição gratuita já configurada.

## Estado de validação

O que foi testado e o que ainda não foi está em [VALIDACAO.md](VALIDACAO.md). Rode o teste de 8 segundos na sua máquina antes de começar um projeto real.

## Créditos

Adaptação didática por Trombino / Criativos do Futuro, baseada no [HyperFrames Student Kit de Nate Herk](https://github.com/nateherkai/hyperframes-student-kit). O motor [HyperFrames](https://github.com/heygen-com/hyperframes) é um projeto de terceiros. Preservamos LICENSE, THIRD_PARTY_NOTICES.md e licenses/. Marcas e exemplos de terceiros não representam endosso.
