"""Deixa as skills do kit valendo em qualquer conversa do Claude (skills pessoais).

Copia cada skill de `.claude/skills/` do kit para a pasta de skills pessoais do Claude
(`~/.claude/skills/`) e coloca no começo de cada uma um aviso com o caminho do kit: assim, numa
conversa aberta em qualquer pasta, o Claude usa os programas e as regras do curso que ficam no kit
e guarda os projetos em `video-projects/` do kit.

Também libera o acesso fixo do Claude à pasta do kit (`permissions.additionalDirectories` em
`~/.claude/settings.json`), com backup antes.

Nunca sobrescreve uma skill que não veio do kit (sem o arquivo-marca). Rodar de novo atualiza.

Uso (a partir de qualquer pasta):
    python scripts/instalar_skills_globais.py            instala ou atualiza
    python scripts/instalar_skills_globais.py --remover  tira as skills do kit e o acesso fixo
Opções de teste: --destino PASTA_DE_SKILLS  --settings ARQUIVO  --sem-acesso
"""
from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import sys
import tempfile
import time
from pathlib import Path

MARCA = ".kit-edit-com-claude.json"
INICIO_AVISO = "<!-- kit-edit-com-claude:aviso -->"
FIM_AVISO = "<!-- /kit-edit-com-claude:aviso -->"


def aviso(kit: Path) -> str:
    k = str(kit)
    return (
        f"{INICIO_AVISO}\n"
        f"> **Skill do kit do curso Edit com Claude Code.** Os programas, as regras e os projetos do\n"
        f"> curso ficam na pasta do kit: `{k}`\n"
        f">\n"
        f"> - Antes de começar, leia `{k}{os.sep}CLAUDE.md` e siga as regras do curso.\n"
        f"> - Quando esta skill falar em \"raiz do kit\", pasta do kit ou num caminho relativo como\n"
        f">   `.claude/skills/...`, `.venv`, `scripts/` ou `video-projects/`, é dentro dessa pasta.\n"
        f">   Rode os comandos a partir dela, mesmo que a conversa esteja aberta em outra pasta.\n"
        f"> - Guarde cópias de vídeo, projetos e renders em `{k}{os.sep}video-projects`, nunca na\n"
        f">   pasta da conversa, a menos que o aluno peça outro lugar.\n"
        f"> - As skills do kit têm nomes com `trombs-` na frente. Quando um texto do kit citar outra\n"
        f">   skill pelo nome curto (ex.: `hyperframes`, `cut-silences`), use a versão com o prefixo\n"
        f">   (`trombs-hyperframes`, `trombs-cut-silences`). A principal se chama só `trombs`.\n"
        f"> - Se a pasta do kit não existir, explique ao aluno que é preciso reinstalar o kit (aula 03).\n"
        f"{FIM_AVISO}\n\n"
    )


def com_aviso(texto: str, kit: Path) -> str:
    """Insere o aviso logo depois do frontmatter (--- ... ---) do SKILL.md."""
    if INICIO_AVISO in texto:  # já tem (não deveria, a cópia vem do kit)
        a = texto.index(INICIO_AVISO)
        b = texto.index(FIM_AVISO) + len(FIM_AVISO)
        texto = texto[:a] + texto[b:].lstrip("\n")
    if texto.startswith("---"):
        fim = texto.find("\n---", 3)
        if fim != -1:
            corte = texto.find("\n", fim + 4)
            corte = len(texto) if corte == -1 else corte + 1
            return texto[:corte] + "\n" + aviso(kit) + texto[corte:].lstrip("\n")
    return aviso(kit) + texto


def nome_da_skill(sk: Path) -> str:
    """O nome que aparece no / (campo name: do SKILL.md); sem ele, o nome da pasta."""
    m = re.match(r"---\r?\nname:\s*([a-z0-9-]+)", sk.read_text(encoding="utf-8"))
    return m.group(1) if m else sk.parent.name


def ler_json(p: Path):
    if not p.exists():
        return {}
    return json.loads(p.read_text(encoding="utf-8-sig"))


def gravar_json(p: Path, dados) -> None:
    p.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=str(p.parent), prefix=p.name, suffix=".tmp")
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        json.dump(dados, f, ensure_ascii=False, indent=2)
        f.write("\n")
    os.replace(tmp, p)


def acesso_fixo(settings: Path, kit: Path, remover: bool, backups: Path) -> str:
    try:
        dados = ler_json(settings)
    except (json.JSONDecodeError, UnicodeDecodeError):
        return f"NÃO MEXI no acesso fixo: {settings} não é um JSON válido. Corrija ou peça ajuda ao suporte."
    if not isinstance(dados, dict):
        return f"NÃO MEXI no acesso fixo: {settings} tem um formato inesperado."
    perms = dados.get("permissions")
    if perms is None:
        perms = {}
    if not isinstance(perms, dict):
        return f"NÃO MEXI no acesso fixo: 'permissions' em {settings} tem um formato inesperado."
    dirs = perms.get("additionalDirectories", [])
    if not isinstance(dirs, list):
        return f"NÃO MEXI no acesso fixo: 'additionalDirectories' em {settings} tem um formato inesperado."
    alvo = os.path.normcase(os.path.normpath(str(kit)))
    tem = [d for d in dirs if isinstance(d, str) and os.path.normcase(os.path.normpath(os.path.expanduser(d))) == alvo]
    if remover:
        if not tem:
            return "acesso fixo: nada a remover."
        novos = [d for d in dirs if d not in tem]
    else:
        if tem:
            return "acesso fixo à pasta do kit: já estava liberado."
        novos = dirs + [str(kit)]
    if settings.exists():
        backups.mkdir(parents=True, exist_ok=True)
        bk = backups / f"claude-settings-{time.strftime('%Y%m%d-%H%M%S')}.json"
        shutil.copy2(settings, bk)
    else:
        bk = None
    if novos:
        perms["additionalDirectories"] = novos
    else:
        perms.pop("additionalDirectories", None)
    if perms:
        dados["permissions"] = perms
    else:
        dados.pop("permissions", None)
    gravar_json(settings, dados)
    conf = ler_json(settings)  # confere o que ficou gravado
    ok = (str(kit) in conf.get("permissions", {}).get("additionalDirectories", [])) != remover
    if not ok:
        return "ERRO: o acesso fixo não ficou gravado como esperado."
    extra = f" (backup: {bk})" if bk else ""
    return ("acesso fixo à pasta do kit: removido" if remover else "acesso fixo à pasta do kit: liberado") + extra


def main(argv=None) -> int:
    kit = Path(__file__).resolve().parent.parent
    base = Path(os.environ.get("CLAUDE_CONFIG_DIR") or (Path.home() / ".claude"))
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--remover", action="store_true")
    ap.add_argument("--destino", type=Path, default=Path.home() / ".claude" / "skills")
    ap.add_argument("--settings", type=Path, default=base / "settings.json")
    ap.add_argument("--sem-acesso", action="store_true", help="não mexe no acesso fixo")
    a = ap.parse_args(argv)

    origem = kit / ".claude" / "skills"
    if not (kit / "CLAUDE.md").exists() or not origem.is_dir():
        print(f"ERRO: não achei o kit em {kit} (falta CLAUDE.md ou .claude/skills).")
        return 2
    versao = ""
    try:
        versao = ler_json(kit / "edition.json").get("version", "")
    except Exception:
        pass

    destino: Path = a.destino
    destino.mkdir(parents=True, exist_ok=True)
    feitas, conflitos, removidas = [], [], []

    if a.remover:
        for d in sorted(destino.iterdir()):
            m = d / MARCA
            if d.is_dir() and m.exists():
                shutil.rmtree(d)
                removidas.append(d.name)
    else:
        fontes = sorted(p for p in origem.iterdir() if (p / "SKILL.md").is_file())
        nomes = {s.name: nome_da_skill(s / "SKILL.md") for s in fontes}
        # cópias de instalações antigas do kit com outro nome (ex.: antes do prefixo trombino-)
        for d in sorted(destino.iterdir()):
            if d.is_dir() and (d / MARCA).exists() and d.name not in nomes.values():
                shutil.rmtree(d)
                removidas.append(d.name)
        for s in fontes:
            nome = nomes[s.name]
            d = destino / nome
            if d.exists() and not (d / MARCA).exists():
                conflitos.append(nome)  # skill de outra origem com o mesmo nome: não mexe
                continue
            tmp = destino / f".{nome}.instalando"
            if tmp.exists():
                shutil.rmtree(tmp)
            shutil.copytree(s, tmp, ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
            sk = tmp / "SKILL.md"
            sk.write_text(com_aviso(sk.read_text(encoding="utf-8"), kit), encoding="utf-8")
            (tmp / MARCA).write_text(json.dumps(
                {"kit": str(kit), "versao_kit": versao, "skill": nome, "pasta_no_kit": s.name,
                 "instalado_em": time.strftime("%Y-%m-%d %H:%M:%S")}, ensure_ascii=False, indent=2),
                encoding="utf-8")
            if d.exists():
                shutil.rmtree(d)
            os.replace(tmp, d)
            feitas.append(nome)

    acesso = "acesso fixo: não mexi (--sem-acesso)." if a.sem_acesso else \
        acesso_fixo(a.settings, kit, a.remover, kit / "backups")

    print(f"Kit: {kit}" + (f" (versão {versao})" if versao else ""))
    print(f"Pasta das skills pessoais: {destino}")
    if a.remover:
        print(f"Skills do kit removidas: {len(removidas)}" + (f" ({', '.join(removidas)})" if removidas else ""))
    else:
        print(f"Skills instaladas no Claude todo: {len(feitas)}")
        if feitas:
            print("  " + ", ".join("/" + n for n in feitas))
        if removidas:
            print(f"Cópias antigas do kit removidas: {', '.join(removidas)}")
        if conflitos:
            print(f"NÃO MEXI em {len(conflitos)} skill(s) que já existiam com o mesmo nome e não são do kit: "
                  + ", ".join(conflitos))
    print(acesso)
    return 1 if (conflitos or acesso.startswith(("ERRO", "NÃO MEXI"))) else 0


if __name__ == "__main__":
    sys.exit(main())
