# Validação — versão 3.1.0 (04/11/2026)

Kit Edit com Claude Code, baseado no Kit Trombino 2.1.4.

## Novidades da 3.1.0

- **Skills no Claude todo:** `scripts/instalar_skills_globais.py` copia as 16 skills para as
  skills pessoais do Claude (`~/.claude/skills/`). Assim elas aparecem em qualquer conversa, e cada
  cópia aponta para a pasta do kit (programas, regras e projetos). O script também libera o acesso
  fixo à pasta do kit, com backup. Ele nunca sobrescreve uma skill do aluno com o mesmo nome.
  - Testado numa pasta de teste: instala, atualiza, preserva a skill do aluno e remove.
  - Testado no PC do Matheus: instalou as 16 skills, e o acesso fixo passou a valer na hora,
    numa conversa já aberta.
- **Decupagem (`decupagem-pt`):**
  - revisão editorial obrigatória, em que o Claude lê o roteiro inteiro;
  - opção `estender_fim` / `estender_inicio` para palavra cortada no meio;
  - regras para autocorreção no meio da frase e para emendas coladas.
  - No IMG_1292 (VSL de 8:25), o resultado foi 3:23. Os 4 pontos apontados pelo Matheus na
    escuta foram corrigidos.

## Onde foi testado

Computador do Matheus, já usado no dia a dia (não é um computador limpo): Windows 11, Intel i7-10750H, 32 GB de RAM, placa NVIDIA GTX 1650.

## O que funcionou

- **Node 26.13.0 e npm 11.20.0.**
- **`npm ci`** terminou em 197 s. O npm 11 bloqueia os "install scripts" de 4 pacotes (@google/genai, esbuild, onnxruntime-node e protobufjs); mesmo assim, o render funcionou.
- **Navegador do render:** foi preciso rodar `npx hyperframes browser ensure` (instala o Chrome Headless Shell).
- **Teste de 8 segundos** renderizado em 16,8 s (1080p, 30 fps, H.264).
- **Decupagem (`decupagem-pt`)** rodando de dentro do kit: gravação de 3:45 virou 1:52, em 225 s de processamento. Os 5 critérios da conferência foram aprovados.
- **MCP do Premiere (`premiere_pro_trombino`)** conectado usando o Node do sistema, com 180 ferramentas disponíveis.

Esses tempos valem para este computador e estes arquivos de teste. Não são promessa para outros vídeos ou computadores.

## Checagem do kit depois da adaptação para o Claude Code

`npm run check` não foi rodado antes desta adaptação. Depois dela (30/10/2026, Node 26.13.0):

- `npm run check`: 595 arquivos, 2 estilos, 406 cards e 16 skills em `.claude/skills`; zero erros.
- `npm test`: 12 testes aprovados, zero falhas.

Nesta adaptação só mudaram textos, a checagem do kit e os caminhos das skills nos testes. Não houve novo render nem nova decupagem depois dela.

## Instalação pelo link (04/11/2026)

- `INSTALAR.md` criado: Parte 1 (kit, skills e decupagem), Parte 2 (HyperFrames) e atualização sem
  perder projetos.
- Instalador do Premiere para o Claude (`premiere-setup-claude-1.0.0`), adaptado do 1.3.5. Testados
  numa configuração de teste: conferência, registro no Claude, recusa em sobrescrever um MCP existente
  e reaproveitamento de uma instalação do curso anterior. O servidor inicia e mostra o catálogo de
  ferramentas e a transcrição.

## Ainda não validado

- Instalação pelo link num computador limpo (Parte 1, Parte 2 e Premiere).
- Conexão real com o Premiere pelo pacote `premiere-setup-claude-1.0.0`.
- Mac.
- MCPs de DaVinci, CapCut e Final Cut com o Claude.
- Decupagem: no vídeo da aula (IMG_1292) sobraram erros, respirações e repetições. Ajuste pendente.

## Conteúdo do pacote

O pacote exclui node_modules, `.venv`, ferramentas baixadas, arquivos .env, gravações pessoais, projetos de edição, renders, fontes particulares e perfis pessoais. Dependências são instaladas na máquina do aluno. Licenças e créditos foram preservados.
