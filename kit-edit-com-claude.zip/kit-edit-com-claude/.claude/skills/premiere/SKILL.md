---
name: trombs-premiere
description: Conectar o Claude ao Adobe Premiere Pro pelo MCP do curso (trombs-premiere) e usar com segurança — instalar ou conferir a conexão, importar a decupagem (XML) numa sequência nova e ler a timeline. Use quando o aluno falar em Premiere, MCP, "conectar o editor", "o Claude não acha o Premiere", ou pedir para mandar algo para a timeline.
---

# Premiere com o Claude (MCP do curso)

O MCP é o "plugue" que deixa o Claude mexer no Premiere. No curso ele se chama
**`trombs-premiere`** (instalações antigas usam `premiere_pro_trombino` e funcionam igual).
As ferramentas aparecem como `mcp__trombs-premiere__...`. O catálogo é por busca: encontre a
ferramenta com `search_tools`, veja os parâmetros com `get_tool_schema` e chame com `invoke_tool`.

## 1. Já está instalado?

Veja se há ferramentas `mcp__trombs-premiere__...` (ou `mcp__premiere_pro_trombino__...`) nesta
conversa.

- **Não há:** o MCP não está instalado, ou foi instalado depois que esta conversa abriu.
  - Se o aluno acabou de instalar, peça para ele abrir uma **conversa nova**.
  - Se nunca instalou, siga o guia oficial do curso:
    https://github.com/CriativosdoFuturo/kit-edit-com-claude/blob/main/INSTALAR-PREMIERE.md
    Leia o guia inteiro antes e siga as regras dele (backup, não sobrescrever outro MCP, pedir uma
    ação por vez).
- **Há:** siga para o passo 2.

## 2. Conferir a conexão (só leitura)

1. O Premiere precisa estar aberto **com um projeto**. Só depois o aluno abre
   **Janela > Extensões > MCP Bridge**. Peça uma ação por vez.
2. Use uma ferramenta de status ou de leitura do projeto (procure com `search_tools`, por
   exemplo "status", "project info") e diga ao aluno, em português simples:
   - se está conectado;
   - qual projeto está aberto;
   - qual sequência está ativa.
3. Se não conectar, confira nesta ordem:
   - o Premiere está aberto com projeto;
   - o painel MCP Bridge está aberto;
   - a conversa é nova, aberta depois da instalação.

   Persistindo, rode o `doctor.mjs` da instalação (pasta `CriativosdoFuturo\PremiereMCP`) e
   explique o resultado. Não reinstale nem apague pastas sem o aluno pedir.

## 3. Usar com segurança

- **Antes de importar ou mudar qualquer coisa, confira qual projeto está ativo.** O aluno pode ter
  outros projetos abertos, inclusive de clientes. Se não for o projeto certo, pare e pergunte.
- **Sempre numa sequência nova.** Nunca edite a sequência original nem uma versão anterior.
- **Nunca salve o projeto** sem o aluno pedir.
- Antes de reiniciar o Premiere ou o Claude, peça para o aluno salvar o trabalho dele.
- **Importar a decupagem:** use `import_fcp_xml` com o `decupagem.xml` da pasta `decupagem-final`
  (veja a skill `trombs-decupagem-pt`). O XML já cria uma sequência nova com data e hora no nome.
  Depois abra essa sequência e diga ao aluno o nome dela.
- Use só as ferramentas necessárias para o pedido. Não rode testes de edição que o aluno não pediu.

## 4. O que dizer ao aluno no fim

Em português simples:
- o que foi feito no Premiere (qual projeto, qual sequência nova);
- o que não foi feito;
- o lembrete de que o projeto **não foi salvo**: ele salva quando quiser.
