---
name: decupagem-pt
description: Decupagem automática de fala em português — corta erros, tentativas, repetições, falas de bastidor e pausas, e entrega uma sequência nova para o Premiere (XML). Use quando o aluno pedir para decupar, limpar, "tirar as repetições", "cortar os erros", "cortar as pausas" ou "tirar os silêncios" de uma gravação de fala (áudio ou vídeo) em português. Também gera áudio decupado, tabela de decisões e imagens de cada emenda, e confere o próprio resultado.
---

# Decupagem de fala em português

Script: `.claude/skills/decupagem-pt/decupar.py`. Ele nunca altera o arquivo de entrada.
Rode todos os comandos a partir da **raiz do kit** (a pasta que tem o `CLAUDE.md`).

## Quando usar

- "decupa esse vídeo", "corta as repetições", "tira os erros e as pausas"
- gravação de fala em português (aula, reels, narração, podcast solo)
- o aluno quer ouvir o resultado e/ou ver os cortes no Premiere

Não use para música, para várias pessoas falando ao mesmo tempo, ou para outro idioma.

## Preparação (uma vez por computador, normalmente já feita na instalação do kit)

Se `.venv` não existir na raiz do kit:

- **Windows:** Python 3.10+ (`winget install --id Python.Python.3.13 -e`), ffmpeg
  (`winget install --id Gyan.FFmpeg -e`), depois:
  ```
  python -m venv .venv
  .venv\Scripts\python -m pip install torch --index-url https://download.pytorch.org/whl/cpu
  .venv\Scripts\python -m pip install -r .claude\skills\decupagem-pt\requirements.txt
  ```
- **Mac (ainda não testado):** `brew install ffmpeg python`, depois:
  ```
  python3 -m venv .venv
  .venv/bin/python -m pip install torch
  .venv/bin/python -m pip install -r .claude/skills/decupagem-pt/requirements.txt
  ```
  No Mac a transcrição roda no processador: espere bem mais tempo que numa placa NVIDIA.

Na primeira decupagem são baixados o `large-v3-turbo` (~1,6 GB) e o modelo de alinhamento
(~1,3 GB). Com placa NVIDIA, o script mede uma vez qual modo é mais rápido nessa placa e guarda a
escolha em `~/.cache/decupar-pt/gpu.json`.

## Como rodar

1. Crie uma pasta do projeto: `video-projects/<nome>/` e **copie** o vídeo para lá (nunca
   trabalhe no original).
2. Descubra o fps da sequência do Premiere (pergunte ou leia pelo MCP; padrão 30).
3. Rode (Windows; no Mac use `.venv/bin/python` e barras normais):
   ```
   .venv\Scripts\python -I .claude\skills\decupagem-pt\decupar.py video-projects\<nome>\<video> --saida video-projects\<nome>\decupagem --fps 30
   ```
   Leva alguns minutos (3:45 de fala ≈ 3 min numa GTX 1650). Rode em segundo plano e avise o aluno.
   Esta primeira rodada é um **rascunho**: não importe no Premiere ainda.
3b. **Revisão editorial (obrigatória).** O script acha os cortes pelo som e por palavras
   parecidas, mas não entende o roteiro. Você entende. Leia `decupagem\trechos-revisao.md`
   inteiro, do começo ao fim, como um editor que lê o roteiro, e escreva `decupagem\revisao.json`
   (veja "Revisão editorial" abaixo). Depois rode de novo, reaproveitando a transcrição (é rápido):
   ```
   .venv\Scripts\python -I .claude\skills\decupagem-pt\decupar.py video-projects\<nome>\<video> --saida video-projects\<nome>\decupagem-final --fps 30 --reusar-transcricao video-projects\<nome>\decupagem\transcricao.json --revisao video-projects\<nome>\decupagem\revisao.json
   ```
   Leia a retranscrição em `decupagem-final\conferencia.md`. Se ainda sobrar repetição, conversa
   ou pedaço solto, ajuste o `revisao.json` e rode de novo. Use sempre a pasta `decupagem-final`
   nos passos seguintes.
4. Leia o fim do log: a conferência imprime os critérios (a, b, c, d, e) e qualquer problema.
5. Olhe as imagens `emendas-N.png` (Read): linha azul = corte, faixa vermelha = o que saiu,
   tracejado laranja = limite de silêncio. A linha azul tem que cair onde a onda está
   "achatada"; palavra mantida (preta) nunca é atravessada pela linha.
6. **No Premiere** (MCP do Premiere): confira qual projeto está ativo (`app.project.name`) — o
   aluno pode ter outros projetos abertos —, importe o `decupagem.xml` nesse projeto e abra a
   sequência nova. No MCP do curso (catálogo por busca), a ferramenta é `import_fcp_xml`: encontre-a
   com `search_tools` e chame com `invoke_tool`. **Nunca edite a sequência original nem uma versão anterior**; o XML já cria
   uma sequência nova com data e hora no nome. Não salve o projeto sem o aluno pedir.
7. Entregue ao aluno, nesta ordem e em português simples: duração antes/depois, o que foi
   cortado (por tipo), as escolhas da revisão em que uma versão substituiu outra (com o tempo
   original, para ele trocar se preferir), os ALERTAS e qualquer critério que falhou. Peça para
   ele ouvir e apontar problemas com o tempo exato.

Para testar ajustes sem retranscrever: `--reusar-transcricao <pasta anterior>\transcricao.json`.

## Revisão editorial

O objetivo é que a timeline final tenha **uma vez só** cada fala, sem conversa de bastidor e sem
pedaço solto. Em `trechos-revisao.md` cada trecho aparece com número (#id), tempo, a decisão do
script e as palavras numeradas a partir de 0 (~~riscada~~ = o script já cortou).

**Corte:**

- **Conversa de bastidor:** falas para a equipe ou para si mesmo, e não para o público. Exemplos:
  combinar o roteiro, "pode ser?", "perfeito" de confirmação, "tá bom", "vamos lá", contagem
  "3, 2, 1", agradecer ou chamar alguém pelo nome, chamar alguém de fora, comentários sobre a
  gravação ou sobre o que entra no vídeo. Em gravação com mais gente na sala, isso pode durar
  vários trechos seguidos.
- **Tentativas anteriores da mesma frase**, mesmo com outras palavras. Fica a **última versão
  completa**. Exemplos: três jeitos de "Sendo assim, te convido…" → fica o último; vários finais
  "a aula é gratuita…" → fica o último completo.
- **Pedaços soltos e frases abandonadas** ("E…", "Mas, basicamente…", "Ou…", frase que termina em
  "…" e é retomada depois).
- **Início ou fim repetido** dentro de um trecho mantido: corte só as palavras repetidas
  (`cortar_palavras`), deixando a frase inteira uma vez.

**Mantenha:**

- repetição de ênfase ("muito, muito", "não, não, não" dito de propósito);
- frase dita uma vez só, mesmo com um errinho;
- na dúvida entre duas ideias **diferentes**, as duas.

Confira a costura: depois do corte, a frase anterior e a seguinte precisam fazer sentido juntas.
Quando cortar dentro de um trecho, prefira cortar no começo ou no fim, onde há pausa.

**Formato do `revisao.json`:**

```json
{
  "cortar": [9, 10, 11],
  "manter": [32, 59],
  "cortar_palavras": {"23": [[11, 19]], "92": [[11, 30]]},
  "manter_palavras": {"41": [[21, 21]]},
  "motivos": {"9": "fala de bastidor — conversa com a equipe", "23": "falso início, refeito em #24"}
}
```

- `cortar` e `manter` recebem números de trecho. Todo DUVIDOSO precisa ir para um dos dois.
- `cortar_palavras` e `manter_palavras` recebem faixas de palavras (índices inclusivos).
- Nos `motivos`, use as palavras "bastidor", "tentativa interrompida", "repetição" ou
  "hesitação": é assim que o resumo conta os cortes por tipo.

## O que sai (em `video-projects/<nome>/decupagem/`)

| Arquivo | Para quê |
|---|---|
| `decupagem.xml` | importar no Premiere; vira uma sequência nova apontando para o vídeo copiado |
| `audio_decupado.wav` | ouvir o resultado (mesmos cortes do XML) |
| `decisoes.md` | cada trecho com tempo, texto, MANTER / CORTAR / DUVIDOSO e motivo |
| `conferencia.md` | retranscrição do resultado e os 5 critérios |
| `emendas-N.png` | cada emenda vista de perto (onda, energia, palavras) |
| `transcricao.json`, `resumo.json` | dados da rodada |

No Premiere, cada DUVIDOSO e cada ALERTA vira um marcador na sequência; clipes com duvidoso
recebem o rótulo Rose.

## O método (resumo)

1. **Picotar antes de transcrever** — o VAD acha trechos de fala separados por pausas ≥ 0,3 s;
   cada trecho é transcrito sozinho (o Whisper não "engole" repetições).
2. **Transcrição literal** — Whisper large-v3-turbo em português, com tempo por palavra.
2b. **Alinhamento letra a letra** — um modelo acústico de português marca o instante de cada
   letra; é isso que permite cortar sem comer fim de palavra.
3. **Cruzar texto com áudio** — retranscreve isolado o que parecer suspeito.
4. **Agrupar repetições** — fica a ÚLTIMA versão COMPLETA de cada frase; tentativa interrompida
   sai; casos duvidosos (duas versões completas e diferentes) ficam as duas, marcadas DUVIDOSO.
   Falas de bastidor claras ("tô começando a gravar", "bora lá", "vou virar aqui", "3, 2, 1")
   saem sempre; palavra solta como "gravar" só vira ALERTA.
4b. **Revisão editorial** — o Claude lê o roteiro inteiro e decide o que o script não percebe:
   conversa de bastidor, regravações com outras palavras e pedaços soltos (`--revisao`).
5. **Emendas no silêncio** — todo corte cai num quadro do vídeo em silêncio; se as palavras
   estão coladas, a emenda anda até a pausa natural mais próxima. Pausas longas ficam ~0,3 s.
6. **Conferência** — (a) nenhuma repetição sobrou, (b) nenhuma ideia sumiu, (c) última palavra
   antes de cada emenda inteira, (d) duvidosos são mesmo duvidosos, (e) toda emenda em silêncio.

## Regras de bom senso

- Tentativa repetida da mesma frase: fica a última versão completa (revisão editorial).
- Na dúvida entre duas ideias diferentes, manter as duas.
- Repetição enfática ("muito, muito", "não, não") não é cortada.
- Se um critério da conferência falhar, explique em português simples o que aconteceu.
