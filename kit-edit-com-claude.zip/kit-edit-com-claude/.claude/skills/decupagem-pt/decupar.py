#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
decupar.py - decupagem automatica de fala em portugues
=====================================================

Corta erros, repeticoes e pausas de uma gravacao de fala (audio ou video) e gera:

    transcricao.json     palavras (texto, inicio, fim, prob) por trecho
    decisoes.md          tabela legivel: trecho, tempo, texto, MANTER / CORTAR / DUVIDOSO e motivo
    audio_decupado.wav   resultado para ouvir (mesmos cortes do XML)
    decupagem.xml        sequencia Final Cut Pro 7 XML (importa no Premiere) com os cortes
                         aplicados sobre o arquivo de entrada
    conferencia.md       retranscricao do audio_decupado.wav e checagem de repeticoes que sobraram

Uso
---
    python decupar.py ENTRADA [--saida PASTA] [--device auto|cuda|cpu] [--fps 30] ...
    python decupar.py --ajuda-parametros          (lista todos os parametros com explicacao)

O metodo (camadas)
------------------
1. PICOTAR ANTES DE TRANSCREVER. O VAD Silero (embutido no faster-whisper) acha os trechos
   de fala separados por pausas >= --pausa-trecho (0,3 s). Cada trecho e transcrito SOZINHO,
   para o Whisper nao "engolir" uma repeticao juntando duas tentativas numa frase so.
2. TRANSCRICAO LITERAL. language="pt", word_timestamps=True, condition_on_previous_text=False
   e um initial_prompt cheio de hesitacoes e repeticoes, que induz o modelo a escrever o que
   foi dito (inclusive "eu vou, eu vou") em vez de "limpar" a fala.
3. CRUZAR TEXTO COM AUDIO. Sao suspeitos e retranscritos isolados:
     a) trecho com fala detectada e nenhuma palavra transcrita;
     a2) lacuna dentro do trecho (>= --lacuna-min) sem palavra mas com energia de voz;
     b) palavra com duracao anormal (> --palavra-longa, 1,2 s);
     c) texto que e eco do initial_prompt (alucinacao classica do prompt).
4. AGRUPAR REPETICOES. Texto normalizado (minusculas, sem acento/pontuacao). Do fim para o
   comeco, cada trecho e comparado com os anteriores proximos. Tentativas parecidas (mesmo com
   palavras diferentes) formam um grupo; fica a ULTIMA versao COMPLETA e a tentativa
   interrompida sai. Se as duas versoes sao completas mas dizem coisas diferentes, ou a
   semelhanca fica no meio-termo, as duas ficam e o grupo e marcado DUVIDOSO.
   Dentro de um trecho tambem sao cortadas repeticoes coladas ("eu vou, eu vou falar"),
   hesitacoes nas pontas ("hum", "ãh") e REFORMULACOES: frase que e dita de novo de outro
   jeito logo em seguida, sem pausa ("isso e crime? Mas na real, isso e realmente um crime?")
   - fica a ultima versao e o trecho ganha um alerta para conferir.
   Pedaco de uma palavra, curtissimo (< --fragmento-max), solto entre duas tentativas da
   mesma frase, e cortado; se for mais longo, so vira alerta.
5. PAUSAS. Silencios > --pausa-max (0,6 s) sao cortados deixando --margem-inicio (80 ms) antes
   da fala e protegendo o fim das palavras com --protecao-fim (160 ms) depois do fim indicado,
   para nao comer "s" e "f" finais. Pausas menores ficam como estao (respiracao natural).
   EMENDAS NO SILENCIO (v6). Antes, a camada 2b realinha cada trecho letra a letra (wav2vec2
   portugues), porque o tempo das palavras do Whisper erra ate ~150 ms. Cada ponto de corte
   e escolhido entre os QUADROS do video (o Premiere so corta em quadro) e so vale se a
   energia ali for de silencio (limiar de voz + --emenda-db): nunca corta o ultimo som da
   ultima silaba nem deixa entrar o primeiro som da palavra cortada.
   - Saida antes de um corte: primeiro silencio depois da ultima letra e, dentro de 80 ms,
     o ponto mais baixo (leva o fim da palavra inteiro, sem a respiracao da tentativa errada).
   - Entrada: silencio mais perto de --margem-inicio antes da primeira letra (ou do inicio
     do trecho no VAD, se o Whisper nao escreveu uma palavrinha como "E").
   - EMENDA NO RESPIRO: se as palavras estao coladas ("usa‿nas"), a emenda anda para a
     primeira pausa natural dentro do trecho repetido: as palavras iguais ficam da 1a vez e
     a fala continua da 2a ("usa nas redes sociais dele, | que basicamente...").
   - Se nem assim houver silencio, corta no ponto mais baixo e marca ALERTA no Premiere.
   Uma imagem por emenda (emendas-N.png) mostra onda, energia e palavras dos dois lados.
6. CONFERENCIA. O audio_decupado.wav e retranscrito com o mesmo metodo e o detector de
   repeticoes roda de novo; o que sobrar vai para conferencia.md (separando o que e DUVIDOSO
   de proposito do que e problema).

Requisitos
----------
    pip install faster-whisper numpy                 (CPU)
    pip install nvidia-cublas-cu12 "nvidia-cudnn-cu12==9.*"   (GPU NVIDIA no Windows)
    ffmpeg e ffprobe no PATH (ou instalados pelo winget: winget install Gyan.FFmpeg)

O arquivo de entrada NUNCA e alterado: ele so e lido.
"""
from __future__ import annotations

import argparse
import json
import math
import os
import re
import shutil
import subprocess
import sys
import time
import unicodedata
import wave
from dataclasses import dataclass, asdict
from difflib import SequenceMatcher
from pathlib import Path
from urllib.parse import quote
from xml.sax.saxutils import escape

import numpy as np

SR = 16000  # taxa usada para analise e transcricao

PROMPT_PADRAO = (
    "É... então, então eu vou, eu vou falar... hã, hoje eu vou, hoje eu quero te mostrar, "
    "é, como que, como que funciona isso."
)


# --------------------------------------------------------------------------------------
# Parametros
# --------------------------------------------------------------------------------------
@dataclass
class Config:
    modelo: str = "large-v3-turbo"
    device: str = "auto"            # auto | cuda | cpu
    prompt: str = PROMPT_PADRAO
    # camada 1
    pausa_trecho: float = 0.30      # pausa minima que separa dois trechos (s)
    trecho_max: float = 20.0        # trecho maior que isso e dividido (s)
    vad_limiar: float = 0.5
    # camada 3
    palavra_longa: float = 1.2      # palavra mais longa que isso e suspeita (s)
    lacuna_min: float = 0.5         # lacuna sem palavra dentro do trecho que vale checar (s)
    ruido_max: float = 0.4          # trecho sem palavra e mais curto que isso = ruido/respiracao
    # camada 4
    janela_s: float = 30.0          # distancia maxima entre tentativas comparadas (s)
    janela_trechos: int = 6         # quantos trechos para tras comparar
    sim_alta: float = 0.80
    sim_prefixo: float = 0.60
    sim_media: float = 0.55
    fragmento_max: float = 0.60     # pedaco solto entre tentativas mais curto que isso e cortado (s)
    reformulacao_min: float = 0.80  # quanto da frase anterior precisa reaparecer na seguinte
    # camada 5
    pausa_max: float = 0.60         # silencio maior que isso e cortado (s)
    margem_inicio: float = 0.08     # margem antes do inicio da fala (s)
    protecao_fim: float = 0.16      # protecao depois do fim da ultima palavra (s)
    fade: float = 0.004             # micro-fade nas emendas do wav (s)
    emenda_db: float = 6.0          # um ponto de emenda e "silencio" se a energia ali fica abaixo de
                                    # limiar_de_voz + isso (dB). Respiracao fraca conta como silencio.
    alinhador: str = "jonatasgrosman/wav2vec2-large-xlsr-53-portuguese"  # alinhamento letra a letra
    # saida
    fps: float = 30.0               # timebase do XML (30, 25, 24, 60, 29.97, 23.976 ...)
    jcut_max: float = 0.6           # J-cut: no maximo isso de fala encavalada (s)
    conferir: bool = True


AJUDA_PARAMETROS = """
--pausa-trecho  0.30  pausa que separa trechos na camada 1. Menor = mais trechos (pega mais
                      repeticoes separadas por pausinha), mas o Whisper perde contexto.
--palavra-longa 1.20  palavra com duracao maior e suspeita (camada 3b).
--pausa-max     0.60  silencio maior que isso e cortado (camada 5).
--margem-inicio 0.08  quanto de silencio deixar antes da fala quando corta uma pausa.
--protecao-fim  0.16  quanto deixar depois do fim indicado da ultima palavra (protege s/f).
--sim-alta      0.80  semelhanca a partir da qual duas tentativas sao "a mesma frase".
--sim-prefixo   0.60  semelhanca minima para "tentativa interrompida, refeita a seguir".
--sim-media     0.55  abaixo disso nao ha relacao; entre isso e as regras de corte = DUVIDOSO.
--fragmento-max 0.60  pedaco de 1 palavra, solto entre duas tentativas da mesma frase e mais
                      curto que isso, e cortado (ex.: um "porque" perdido). Mais longo vira alerta.
--reformulacao-min 0.80  dentro do mesmo trecho, se a frase seguinte repete pelo menos isso das
                      palavras da anterior e termina na mesma palavra, a anterior sai
                      ("isso e crime? Mas na real, isso e realmente um crime?").
--emenda-db     6.0   um ponto so serve de emenda se a energia ali fica abaixo de limiar de
                      voz + isso (dB). Menor = exige silencio mais profundo (mais emendas
                      "coladas" viram alerta); maior = aceita cortar em som mais forte.
--alinhador     (wav2vec2 portugues)  modelo que marca o tempo de cada LETRA. Use
                      --sem-alinhamento para pular (as emendas ficam menos precisas).
--sem-imagens         nao gera as imagens das emendas (emendas-N.png).
--fps           30    timebase da sequencia XML (use a do seu projeto).
--device        auto  auto tenta GPU (CUDA float16 -> int8_float16) e cai para CPU int8.
"""


# --------------------------------------------------------------------------------------
# Utilidades
# --------------------------------------------------------------------------------------
def log(msg: str) -> None:
    print(msg, flush=True)


def fmt_t(t: float) -> str:
    t = max(0.0, t)
    return f"{int(t // 60):02d}:{t % 60:05.2f}"


def achar_exe(nome: str) -> str:
    """Acha ffmpeg/ffprobe no PATH, na pasta de links do winget ou no pacote Gyan.FFmpeg."""
    p = shutil.which(nome)
    if p:
        return p
    la = Path(os.environ.get("LOCALAPPDATA", ""))
    cands = [la / "Microsoft" / "WinGet" / "Links" / f"{nome}.exe"]
    pk = la / "Microsoft" / "WinGet" / "Packages"
    if pk.is_dir():
        cands += sorted(pk.glob(f"Gyan.FFmpeg*/**/bin/{nome}.exe"))
    for c in cands:
        if c.is_file():
            return str(c)
    if sys.platform == "darwin":
        raise SystemExit(f"ERRO: {nome} nao encontrado. No Mac, instale com: brew install ffmpeg")
    raise SystemExit(f"ERRO: {nome} nao encontrado. Instale com: winget install Gyan.FFmpeg")


def preparar_cuda() -> None:
    """No Windows, as DLLs do CUDA instaladas via pip (nvidia-*) precisam entrar no PATH."""
    if os.name != "nt":
        return
    import site
    bases = [Path(p) for p in site.getsitepackages()] + [Path(sys.prefix) / "Lib" / "site-packages"]
    for base in bases:
        nv = base / "nvidia"
        if not nv.is_dir():
            continue
        for b in nv.glob("*/bin"):
            try:
                os.add_dll_directory(str(b))
            except OSError:
                pass
            os.environ["PATH"] = str(b) + os.pathsep + os.environ.get("PATH", "")


def sondar(ffprobe: str, arq: str) -> dict:
    out = subprocess.run(
        [ffprobe, "-v", "error", "-show_streams", "-show_format", "-of", "json", arq],
        capture_output=True, check=True,
    ).stdout
    d = json.loads(out)
    a = next((s for s in d["streams"] if s["codec_type"] == "audio"), None)
    if a is None:
        raise SystemExit("ERRO: o arquivo nao tem faixa de audio.")
    v = next((s for s in d["streams"] if s["codec_type"] == "video"
              and not s.get("disposition", {}).get("attached_pic", 0)), None)
    return {
        "duracao": float(d["format"]["duration"]),
        "sr": int(a["sample_rate"]),
        "canais": int(a["channels"]),
        "codec": a.get("codec_name"),
        "video": None if v is None else {"largura": v.get("width"), "altura": v.get("height")},
    }


def decodificar(ffmpeg: str, arq: str, sr: int, canais: int) -> np.ndarray:
    """Decodifica para float32 (amostras x canais) sem gravar nada em disco."""
    raw = subprocess.run(
        [ffmpeg, "-v", "error", "-i", arq, "-vn", "-ac", str(canais), "-ar", str(sr),
         "-f", "f32le", "-"],
        capture_output=True, check=True,
    ).stdout
    x = np.frombuffer(raw, dtype=np.float32)
    return x.reshape(-1, canais) if canais > 1 else x.reshape(-1, 1)


class Energia:
    """Energia em quadros de 10 ms, com limiar adaptativo de 'tem voz aqui'."""

    def __init__(self, audio: np.ndarray, sr: int = SR, hop: float = 0.01):
        n = int(sr * hop)
        m = len(audio) // n
        fr = audio[: m * n].reshape(m, n)
        rms = np.sqrt((fr.astype(np.float64) ** 2).mean(1) + 1e-12)
        self.db = 20 * np.log10(rms + 1e-9)
        self.hop = hop
        piso = float(np.percentile(self.db, 10))
        topo = float(np.percentile(self.db, 98))
        self.piso, self.topo = piso, topo
        self.limiar = max(piso + 12.0, topo - 40.0)
        # resolucao fina para escolher emendas: janelas de 10 ms a cada 5 ms
        n10, h5 = int(sr * 0.01), int(sr * 0.005)
        k = max(0, (len(audio) - n10) // h5)
        c = np.concatenate([[0.0], np.cumsum(audio.astype(np.float64) ** 2)])
        st = np.arange(k) * h5
        self.db5 = 10 * np.log10((c[st + n10] - c[st]) / n10 + 1e-12)

    def janela(self, t: float, r: float = 0.01) -> float:
        """Energia mais alta (dB) perto do instante t (janelas centradas em t-r .. t+r).
        Uma emenda em t e 'limpa' se isso esta perto do silencio."""
        i0 = max(0, int(math.ceil((t - r - 0.005) / 0.005)))
        i1 = min(len(self.db5) - 1, int(math.floor((t + r - 0.005) / 0.005)))
        if i1 < i0:
            return float(self.db5[min(max(i0, 0), len(self.db5) - 1)])
        return float(self.db5[i0: i1 + 1].max())

    def _i(self, t: float) -> int:
        return int(np.clip(round(t / self.hop), 0, len(self.db) - 1))

    def voz(self, a: float, b: float) -> float:
        """Segundos com energia de voz entre a e b."""
        i, j = self._i(a), self._i(b)
        if j <= i:
            return 0.0
        return float((self.db[i:j] > self.limiar).sum() * self.hop)

    def minimo(self, a: float, b: float) -> float:
        """Instante de menor energia entre a e b (bom ponto de corte)."""
        i, j = self._i(a), self._i(b)
        if j <= i:
            return (a + b) / 2
        k = i + int(np.argmin(self.db[i: j + 1]))
        return k * self.hop + self.hop / 2


# --------------------------------------------------------------------------------------
# Normalizacao de texto (camada 4)
# --------------------------------------------------------------------------------------
def normalizar(s: str) -> str:
    s = unicodedata.normalize("NFKD", s.lower())
    s = "".join(c for c in s if not unicodedata.combining(c))
    return re.sub(r"[^a-z0-9]", "", s)


def raw_limpo(s: str) -> str:
    return re.sub(r"[^\wãáàâéêíóôõúç]", "", s.lower())


HESITACOES = {"ah", "ahn", "ãh", "ã", "eh", "éh", "hum", "hm", "hmm", "humm", "uh", "uhm",
              "hã", "han", "ahm", "ehm", "mm", "mhm"}
# "é" so conta como hesitacao quando esta sozinho no trecho ou escrito "é..."
ENFATICAS = {"muito", "nao", "sim", "bem", "mais", "ta", "isso", "nada", "sempre", "nunca",
             "ja", "pouco", "bom", "olha", "vai", "ok", "beleza", "mesmo", "super", "tao",
             "tchau", "oi", "ola", "corre", "vem", "pronto", "calma", "pera"}
# palavras que, no fim de uma tentativa, indicam que ela foi interrompida
FUNCIONAIS_FIM = {"a", "o", "as", "os", "um", "uma", "uns", "umas", "de", "da", "do", "das",
                  "dos", "em", "no", "na", "nos", "nas", "pra", "pro", "pras", "pros", "para",
                  "por", "pelo", "pela", "com", "sem", "e", "ou", "mas", "que", "se", "porque",
                  "como", "quando", "onde", "eu", "voce", "ele", "ela", "vou", "vai", "vamos",
                  "quero", "sou", "esta", "tem", "meu", "minha", "seu", "sua", "nosso", "nossa",
                  "esse", "essa", "este", "ao", "aos", "entao", "te", "me", "lhe", "tipo", "mais",
                  "muito", "isso", "aquele", "aquela", "qual", "cada", "todo", "toda", "num",
                  "numa", "pelos", "pelas", "nesse", "nessa", "desse", "dessa", "deu", "ja"}


# conectivos/contagem que podem abrir uma tentativa sem fazer parte dela ("2, 1, então se você...")
LIDERES = {"entao", "e", "ai", "mas", "bom", "enfim", "tipo", "olha", "agora", "ne", "so",
           "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10"}
# artigos/possessivos no comeco: "Seu nome e Mateus" e tentativa de "O nome do gatinho..."
# (usados so na comparacao de tentativas; no resto do metodo "o"/"a" contam como palavra)
ARTIGOS = {"o", "a", "os", "as", "um", "uma", "seu", "sua", "meu", "minha"}


def sem_artigo(t: list[str]) -> list[str]:
    i = 0
    while i < len(t) - 1 and t[i] in ARTIGOS | LIDERES:
        i += 1
    return t[i:]


def aproximar(a: list[str], b: list[str]) -> list[str]:
    """Troca em b as palavras escritas quase igual a uma palavra de a (Matheus -> Mateus)."""
    return [next((x for x in a if len(x) >= 4 and len(y) >= 4 and x != y
                  and SequenceMatcher(None, x, y).ratio() >= 0.8), y) for y in b]

# fala de bastidor CLARA (comentario sobre a propria gravacao): trecho curto com isso e cortado
BASTIDOR_FORTE = re.compile(
    r"\b(comecando a gravar|comecar a gravar|vou gravar (esse|essa|isso|de novo|aqui|o final|agora)|"
    r"(to|tou|estou|ta|esta) gravando|gravar de novo|grava de novo|vou repetir|deixa eu repetir|"
    r"vou virar|virar aqui|olhando pra camera|pra camera aqui|bora la|deixa eu ver|errei|"
    r"de novo do comeco|valendo|corta isso|ja ta gravando)\b")
# palavras que PODEM ser bastidor, mas tambem aparecem em conteudo ("gravar" num curso de video):
# so viram alerta
BASTIDOR = re.compile(r"\b(gravar|gravando|gravacao|pra camera|para a camera|olhando pra|de novo|"
                      r"bora la|vou virar|virar aqui|errei|deixa eu ver|ta gravando)\b")
BASTIDOR_MAX_PALAVRAS = 20


def nucleo(t: list[str]) -> list[str]:
    i = 0
    while i < len(t) - 1 and t[i] in LIDERES:
        i += 1
    return t[i:]


def sim(a: list[str], b: list[str]) -> float:
    """Semelhanca 0..1: media entre comparacao por palavra e por caractere."""
    if not a or not b:
        return 0.0
    rt = SequenceMatcher(None, a, b, autojunk=False).ratio()
    rc = SequenceMatcher(None, " ".join(a), " ".join(b), autojunk=False).ratio()
    return 0.5 * (rt + rc)


def sim_prefixo(a: list[str], b: list[str]) -> float:
    """Quanto 'a' parece o comeco de 'b' (testa prefixos de b de tamanhos vizinhos)."""
    if not a or not b:
        return 0.0
    lo = max(1, len(a) - 1)
    hi = min(len(b), len(a) + 3)
    return max((sim(a, b[:k]) for k in range(lo, hi + 1)), default=0.0)


def contencao(a: list[str], b: list[str]) -> float:
    """Fracao das palavras de 'a' que aparecem em ordem dentro de 'b'."""
    if not a or not b:
        return 0.0
    sm = SequenceMatcher(None, a, b, autojunk=False)
    return sum(m.size for m in sm.get_matching_blocks()) / len(a)


# --------------------------------------------------------------------------------------
# Modelo e transcricao (camadas 1 e 2)
# --------------------------------------------------------------------------------------
def nome_gpu() -> str:
    try:
        out = subprocess.run(["nvidia-smi", "--query-gpu=name", "--format=csv,noheader"],
                             capture_output=True, text=True, timeout=10).stdout.strip()
        return out.splitlines()[0] if out else "cuda"
    except Exception:  # noqa: BLE001
        return "cuda"


def carregar_modelo(cfg: Config):
    """Carrega o Whisper no modo mais rapido DESTA maquina.
    Placa NVIDIA: float16 e int8_float16 dao o mesmo texto, mas a velocidade muda muito de placa
    para placa (GTX 1650: int8 e 4x mais rapido; RTX costuma ir melhor em float16). Na primeira
    vez o script mede os dois e guarda a escolha em ~/.cache/decupar-pt/gpu.json.
    Sem NVIDIA (inclusive Mac): CPU int8."""
    preparar_cuda()
    from faster_whisper import WhisperModel

    tom = (0.1 * np.sin(2 * np.pi * 220 * np.arange(SR) / SR)).astype(np.float32)

    def testar(m):  # forca o carregamento de cuBLAS/cuDNN agora, nao no meio do trabalho
        segs, _ = m.transcribe(tom, language="pt", word_timestamps=True)
        list(segs)

    def medir(m):  # tempo de uma janela de 30 s (o que cada trecho custa)
        x = (0.05 * np.random.default_rng(0).standard_normal(SR * 8)).astype(np.float32)
        t0 = time.time()
        segs, _ = m.transcribe(x, language="pt", beam_size=5, temperature=[0.0], without_timestamps=True)
        list(segs)
        return time.time() - t0

    cache = Path.home() / ".cache" / "decupar-pt" / "gpu.json"
    # Mac nao tem CUDA: vai direto para a CPU (sem mensagens de erro assustadoras)
    if cfg.device == "cuda" or (cfg.device == "auto" and sys.platform != "darwin"):
        gpu = nome_gpu()
        try:
            salvo = json.loads(cache.read_text(encoding="utf-8"))
        except Exception:  # noqa: BLE001
            salvo = {}
        ordem = [salvo[gpu]] if gpu in salvo else []
        ordem += [c for c in ("float16", "int8_float16") if c not in ordem]
        medidos = {}
        modelos = {}
        for ct in ordem:
            try:
                t0 = time.time()
                m = WhisperModel(cfg.modelo, device="cuda", compute_type=ct)
                testar(m)
                if gpu in salvo:
                    log(f"  modelo {cfg.modelo} em cuda/{ct} ({gpu}, escolha salva) ({time.time() - t0:.1f} s)")
                    return m, "cuda", ct
                medidos[ct] = medir(m)
                modelos[ct] = m
                log(f"  [modelo] {gpu} cuda/{ct}: {medidos[ct]:.1f} s por janela de teste")
            except Exception as e:  # noqa: BLE001
                log(f"  [modelo] cuda/{ct} nao funcionou: {str(e).splitlines()[0][:160]}")
        if medidos:
            ct = min(medidos, key=medidos.get)
            for c in list(modelos):
                if c != ct:
                    del modelos[c]
            try:
                salvo[gpu] = ct
                cache.parent.mkdir(parents=True, exist_ok=True)
                cache.write_text(json.dumps(salvo, ensure_ascii=False, indent=2), encoding="utf-8")
            except Exception:  # noqa: BLE001
                pass
            log(f"  modelo {cfg.modelo} em cuda/{ct} (o mais rápido nesta placa; escolha salva)")
            return modelos[ct], "cuda", ct
    if cfg.device in ("auto", "cpu"):
        try:
            t0 = time.time()
            m = WhisperModel(cfg.modelo, device="cpu", compute_type="int8")
            testar(m)
            log(f"  modelo {cfg.modelo} carregado em cpu/int8 ({time.time() - t0:.1f} s)")
            return m, "cpu", "int8"
        except Exception as e:  # noqa: BLE001
            log(f"  [modelo] cpu/int8 nao funcionou: {str(e).splitlines()[0][:160]}")
    raise SystemExit("ERRO: nao consegui carregar o modelo em nenhum dispositivo.")


# --------------------------------------------------------------------------------------
# Camada 2b: alinhamento forcado letra a letra (wav2vec2 + CTC)
# --------------------------------------------------------------------------------------
# O Whisper erra o tempo das palavras em ate ~150 ms. Para cortar sem comer o fim de uma
# palavra (nem deixar entrar o comeco da proxima), cada trecho e realinhado por um modelo
# acustico de portugues que diz em que instante cada LETRA foi falada (resolucao de 20 ms).
# Cada palavra ganha a_ini (primeira letra) e a_fim (ultima letra). Sem o modelo, a_ini/a_fim
# ficam iguais aos tempos do Whisper.
class Alinhador:
    def __init__(self, nome: str):
        import torch  # noqa: F401
        from transformers import Wav2Vec2ForCTC, Wav2Vec2Processor
        from transformers.utils import logging as hf_log
        hf_log.set_verbosity_error()
        self.torch = torch
        self.proc = Wav2Vec2Processor.from_pretrained(nome)
        self.model = Wav2Vec2ForCTC.from_pretrained(nome).eval()
        self.vocab = self.proc.tokenizer.get_vocab()
        self.blank = self.proc.tokenizer.pad_token_id
        self.sep = self.vocab.get("|")

    def alinhar(self, audio16: np.ndarray, ini: float, fim: float, palavras: list[dict]) -> int:
        i0 = int(max(0.0, ini) * SR)
        i1 = int(min(len(audio16) / SR, fim) * SR)
        seg = audio16[i0:i1]
        if len(seg) < SR * 0.1:
            return 0
        inp = self.proc(seg, sampling_rate=SR, return_tensors="pt").input_values
        with self.torch.inference_mode():
            em = self.torch.log_softmax(self.model(inp).logits[0], -1).numpy().astype(np.float64)
        T = em.shape[0]
        dt = (len(seg) / SR) / T
        toks, dono, letras = [], [], []
        for wi, w in enumerate(palavras):
            ls = [c for c in w["texto"].lower() if c in self.vocab and c not in "|'-"]
            cs = [self.vocab[c] for c in ls]
            if not cs:
                continue
            if toks and self.sep is not None:
                toks.append(self.sep)
                dono.append(-1)
                letras.append("|")
            toks += cs
            dono += [wi] * len(cs)
            letras += ls
        N = len(toks)
        if N == 0 or N > T:
            return 0
        tk = np.array(toks)
        tr = np.full((T + 1, N + 1), -np.inf)
        tr[0, 0] = 0.0
        tr[1:, 0] = np.cumsum(em[:, self.blank])
        for t in range(T):
            tr[t + 1, 1:] = np.maximum(tr[t, 1:] + em[t, self.blank], tr[t, :-1] + em[t, tk])
        if not np.isfinite(tr[T, N]):
            return 0
        quadro = [0] * N
        j = N
        for t in range(T, 0, -1):
            if j == 0:
                break
            if tr[t - 1, j - 1] + em[t - 1, tk[j - 1]] > tr[t - 1, j] + em[t - 1, self.blank]:
                quadro[j - 1] = t - 1
                j -= 1
        n = 0
        for wi, w in enumerate(palavras):
            ks = [quadro[k] for k in range(N) if dono[k] == wi]
            if not ks:
                continue
            a = i0 / SR + min(ks) * dt
            b = i0 / SR + (max(ks) + 1) * dt
            if abs(a - w["inicio"]) > 0.6 or abs(b - w["fim"]) > 0.6:
                continue  # alinhamento suspeito: fica o tempo do Whisper
            w["a_ini"], w["a_fim"] = round(a, 3), round(b, 3)
            # instante de cada letra (usado no J-cut para achar o comeco da ultima silaba)
            w["a_letras"] = [[letras[k], round(i0 / SR + quadro[k] * dt, 3)] for k in range(N) if dono[k] == wi]
            n += 1
        return n


def alinhar_trechos(audio16: np.ndarray, trechos: list[dict], cfg: Config, usar: bool) -> dict:
    t0 = time.time()
    total = sum(len(t["palavras"]) for t in trechos)
    feitos = 0
    estado = "desligado"
    for tr in trechos:
        for w in tr["palavras"]:
            for k in ("a_ini", "a_fim", "a_ini_ef", "a_letras"):
                w.pop(k, None)
    if usar:
        try:
            al = Alinhador(cfg.alinhador)
            estado = "ok"
        except Exception as e:  # noqa: BLE001
            log(f"    [alinhamento] indisponível ({str(e).splitlines()[0][:120]}); uso os tempos do Whisper")
            al, estado = None, "indisponível"
        if al is not None:
            for tr in trechos:
                ws = tr["palavras"]
                if not ws:
                    continue
                ini = min(tr["ini"], ws[0]["inicio"]) - 0.15
                fim = max(tr["fim"], ws[-1]["fim"]) + 0.15
                try:
                    feitos += al.alinhar(audio16, ini, fim, ws)
                except Exception as e:  # noqa: BLE001
                    log(f"    [alinhamento] trecho #{tr['id']} falhou: {str(e)[:100]}")
    for tr in trechos:
        for w in tr["palavras"]:
            w.setdefault("a_ini", w["inicio"])
            w.setdefault("a_fim", w["fim"])
    return {"estado": estado, "palavras": total, "alinhadas": feitos, "tempo_s": round(time.time() - t0, 1)}


def camada1_trechos(audio16: np.ndarray, cfg: Config) -> list[dict]:
    from faster_whisper.vad import VadOptions, get_speech_timestamps

    opts = VadOptions(
        threshold=cfg.vad_limiar,
        min_speech_duration_ms=120,
        min_silence_duration_ms=int(cfg.pausa_trecho * 1000),
        speech_pad_ms=30,
        max_speech_duration_s=cfg.trecho_max,
    )
    ts = get_speech_timestamps(audio16, opts)
    return [{"ini": t["start"] / SR, "fim": t["end"] / SR} for t in ts]


def transcrever_regiao(model, audio16, ini, fim, cfg: Config, sem_prompt=False,
                       pad_real=0.05, temperatura=(0.0, 0.2, 0.4), aceita_antes=None) -> list[dict]:
    """Transcreve SO a regiao [ini, fim] e devolve palavras em tempo absoluto do arquivo, so as
    que caem dentro da regiao (+ pad_real).
    Bordas (testado na r7): 0,2 s de audio REAL antes e silencio digital so DEPOIS. Silencio
    digital ANTES fazia o Whisper pular a 1a palavrinha do trecho em ~20 de 35 trechos
    ("O nome...", "E como...", "Mas agora...", "3, 2, 1"); sem silencio depois, some a ultima."""
    dur = len(audio16) / SR
    a, b = max(0.0, ini - max(pad_real, 0.2)), min(dur, fim + pad_real)
    pad_sil = 0.0
    z = np.zeros(int(0.3 * SR), dtype=np.float32)
    x = np.concatenate([audio16[int(a * SR): int(b * SR)], z]).astype(np.float32)
    segs, _ = model.transcribe(
        x, language="pt", task="transcribe", beam_size=5,
        temperature=list(temperatura),
        condition_on_previous_text=False,
        initial_prompt=None if sem_prompt else cfg.prompt,
        word_timestamps=True, vad_filter=False, without_timestamps=False,
    )
    palavras = []
    for s in segs:
        if s.no_speech_prob > 0.6 and s.avg_logprob < -1.0:
            continue  # segmento que o proprio modelo acha que e silencio -> alucinacao
        for w in s.words or []:
            t0 = w.start - pad_sil + a
            t1 = w.end - pad_sil + a
            meio = (t0 + t1) / 2
            # o 1o "O"/"E" costuma vir com tempo adiantado (dentro dos 0,2 s de contexto)
            antes = max(pad_real, 0.2) if aceita_antes is None else aceita_antes
            if meio < ini - antes or meio > fim + pad_real:
                continue
            txt = w.word.strip()
            if not normalizar(txt):
                continue
            palavras.append({
                "texto": txt,
                "inicio": round(max(a, t0), 3),
                "fim": round(min(b, max(t1, t0 + 0.02)), 3),
                "prob": round(float(w.probability), 3),
            })
    return palavras


# --------------------------------------------------------------------------------------
# Camada 3: cruzar texto com audio
# --------------------------------------------------------------------------------------
def eco_do_prompt(palavras: list[dict], prompt: str) -> bool:
    toks = [normalizar(w["texto"]) for w in palavras]
    toks = [t for t in toks if t]
    if len(toks) < 3:
        return False
    alvo = " ".join(normalizar(p) for p in prompt.split())
    return " ".join(toks) in alvo


def camada3(model, audio16, en: Energia, trechos: list[dict], cfg: Config) -> dict:
    cont = {"fala_sem_palavras": 0, "lacuna_com_voz": 0, "palavra_longa": 0,
            "eco_prompt": 0, "recuperados": 0}
    for tr in trechos:
        tr.setdefault("suspeitas", [])
        ws = tr["palavras"]

        # c) eco do prompt
        if ws and eco_do_prompt(ws, cfg.prompt):
            cont["eco_prompt"] += 1
            novo = transcrever_regiao(model, audio16, tr["ini"], tr["fim"], cfg, sem_prompt=True)
            tr["suspeitas"].append({"tipo": "eco_do_prompt", "antes": " ".join(w["texto"] for w in ws),
                                    "depois": " ".join(w["texto"] for w in novo)})
            ws = novo

        # a) fala detectada e nenhuma palavra
        if not ws:
            cont["fala_sem_palavras"] += 1
            novo = transcrever_regiao(model, audio16, tr["ini"], tr["fim"], cfg, sem_prompt=True)
            if not novo:
                novo = transcrever_regiao(model, audio16, tr["ini"], tr["fim"], cfg, sem_prompt=True,
                                          pad_real=0.25, temperatura=(0.2, 0.4, 0.6))
            tr["suspeitas"].append({"tipo": "fala_sem_palavras",
                                    "resultado": " ".join(w["texto"] for w in novo) or "(nada)"})
            if novo:
                cont["recuperados"] += 1
            ws = novo

        # a2) lacunas com voz dentro do trecho
        if ws:
            marcos = [(tr["ini"], tr["ini"])] + [(w["inicio"], w["fim"]) for w in ws] + [(tr["fim"], tr["fim"])]
            novas = []
            for (_, f0), (i1, _) in zip(marcos[:-1], marcos[1:]):
                if i1 - f0 >= cfg.lacuna_min and en.voz(f0, i1) >= 0.25:
                    cont["lacuna_com_voz"] += 1
                    achou = transcrever_regiao(model, audio16, f0, i1, cfg, sem_prompt=True, pad_real=0.03,
                                               aceita_antes=0.03)
                    achou = [w for w in achou if not any(
                        min(w["fim"], v["fim"]) - max(w["inicio"], v["inicio"]) > 0.5 * (w["fim"] - w["inicio"])
                        for v in ws)]
                    tr["suspeitas"].append({"tipo": "lacuna_com_voz", "ini": round(f0, 3), "fim": round(i1, 3),
                                            "resultado": " ".join(w["texto"] for w in achou) or "(nada)"})
                    if achou:
                        cont["recuperados"] += 1
                        for w in achou:
                            w["origem"] = "retranscrito_lacuna"
                        novas += achou
            ws = sorted(ws + novas, key=lambda w: w["inicio"])

        # b) palavras longas demais
        saida = []
        for w in ws:
            if w["fim"] - w["inicio"] > cfg.palavra_longa:
                cont["palavra_longa"] += 1
                novo = transcrever_regiao(model, audio16, w["inicio"], w["fim"], cfg, sem_prompt=True, pad_real=0.04,
                                          aceita_antes=0.04)
                troca = bool(novo) and (len(novo) > 1 or normalizar(novo[0]["texto"]) != normalizar(w["texto"]))
                tr["suspeitas"].append({"tipo": "palavra_longa", "palavra": w["texto"],
                                        "duracao": round(w["fim"] - w["inicio"], 2),
                                        "resultado": " ".join(v["texto"] for v in novo) or "(nada)",
                                        "substituida": troca})
                if troca:
                    cont["recuperados"] += 1
                    for v in novo:
                        v["origem"] = "retranscrito_palavra_longa"
                    saida += novo
                    continue
            saida.append(w)
        tr["palavras"] = sorted(saida, key=lambda w: w["inicio"])
    return cont


# --------------------------------------------------------------------------------------
# Camada 4: repeticoes
# --------------------------------------------------------------------------------------
def tok(w: dict) -> str:
    return normalizar(w["texto"])


def eh_hesitacao(w: dict, sozinho: bool = False) -> bool:
    r = raw_limpo(w["texto"])
    if r in HESITACOES:
        return True
    if r == "é" and (sozinho or w["texto"].rstrip().endswith("...")):
        return True
    return False


def incompleta(ws: list[dict]) -> bool:
    if not ws:
        return True
    ult = ws[-1]["texto"].rstrip()
    if ult.endswith(("...", "-", "—", "…")):
        return True
    return tok(ws[-1]) in FUNCIONAIS_FIM


def vivas(tr: dict) -> list[dict]:
    """Palavras do trecho que nao foram cortadas internamente."""
    return [w for w in tr["palavras"] if not w.get("corte")]


def cortes_internos(tr: dict, cfg: Config | None = None) -> None:
    """Hesitacoes nas pontas, repeticoes coladas e reformulacoes dentro do mesmo trecho."""
    ws = tr["palavras"]
    if not ws:
        return
    # hesitacoes no comeco e no fim do trecho (no meio fica: cortar ali e arriscado)
    i = 0
    while i < len(ws) - 1 and eh_hesitacao(ws[i]):
        ws[i]["corte"] = "hesitação"
        i += 1
    j = len(ws) - 1
    while j > i and eh_hesitacao(ws[j]):
        ws[j]["corte"] = "hesitação"
        j -= 1
    # reinicios colados: "eu vou, eu vou falar", "a a gente", "que a gente, que a gente"
    toks = [tok(w) for w in ws]
    p = 1
    while p < len(ws):
        if ws[p].get("corte"):
            p += 1
            continue
        achado = 0
        for n in range(min(6, p), 0, -1):
            rep = list(range(p - n, p))
            if any(ws[k].get("corte") for k in rep):
                continue
            R = [toks[k] for k in rep]
            if R[0] != toks[p]:
                continue
            if n == 1:
                if R[0] not in ENFATICAS and len(R[0]) > 0:
                    achado = 1
                break
            alvo = toks[p: p + n + 3]
            s = sim_prefixo(R, alvo)
            if s >= 0.80 and (R[-1] in alvo or R[-1] in FUNCIONAIS_FIM):
                achado = n
                break
        if achado:
            for k in range(p - achado, p):
                ws[k]["corte"] = "repetição interna"
        p += 1
    reformulacoes(tr, cfg.reformulacao_min if cfg else 0.80)


FIM_DE_FRASE = re.compile(r"[?!.…]$")


def reformulacoes(tr: dict, minimo: float) -> None:
    """Frase dita de novo de outro jeito, colada na anterior, dentro do mesmo trecho:
    "agora, isso e crime? Mas na real, isso e realmente um crime?" -> sai a primeira.
    Exige: a frase seguinte contem (em ordem) >= minimo das palavras da anterior, e as duas
    terminam na mesma palavra de conteudo. Citacoes paralelas ("Copiar de um autor e plagio.
    Copiar de muitos e pesquisa!") nao passam: terminam diferente."""
    frases: list[list[dict]] = []
    atual: list[dict] = []
    for w in tr["palavras"]:
        if w.get("corte"):
            continue
        atual.append(w)
        if FIM_DE_FRASE.search(w["texto"].rstrip()):
            frases.append(atual)
            atual = []
    if atual:
        frases.append(atual)
    for fa, fb in zip(frases, frases[1:]):
        if any(w.get("corte") for w in fa):
            continue
        a, b = nucleo([tok(w) for w in fa]), nucleo([tok(w) for w in fb])
        if len(a) < 2 or len(b) < len(a) or a[-1] != b[-1] or a[-1] in FUNCIONAIS_FIM:
            continue
        if contencao(a, b) >= minimo:
            for w in fa:
                w["corte"] = "reformulação; fica a frase seguinte"
            tr.setdefault("alertas", []).append(
                "corte automático: reformulação «" + " ".join(w["texto"] for w in fa) + "» — confira")


def relacao(A: dict, B: dict, cfg: Config):
    """Compara tentativa anterior A com posterior B.
    Devolve (acao, motivo, semelhanca) com acao em CORTA_A / CORTA_B / DUVIDOSO / None."""
    wa, wb = vivas(A), vivas(B)
    a, b = nucleo([tok(w) for w in wa]), nucleo([tok(w) for w in wb])
    if not a or not b:
        return None, "", 0.0
    full = sim(a, b)
    pre = sim_prefixo(a, b)
    ancorado = a[0] == b[0] or (len(a) > 1 and len(b) > 1 and a[1] == b[1]
                                and SequenceMatcher(None, a[0], b[0]).ratio() > 0.6)
    inc_a, inc_b = incompleta(wa), incompleta(wb)
    s = max(full, pre)

    if len(a) == 1:
        if a[0] == b[0] and a[0] not in ENFATICAS | {"nao", "sim"}:
            return "CORTA_A", "falso início (palavra solta repetida logo depois)", 1.0
        if a[0] == b[0] and len(b) > 1:
            return "CORTA_A", "falso início (palavra solta repetida logo depois)", 1.0
        return None, "", s

    # mesma comparacao ignorando artigos e grafia ("Seu nome e Mateus" x "O nome do gatinho e Matheus")
    a2 = sem_artigo(a)
    b2 = aproximar(a2, sem_artigo(b))
    anc2 = bool(a2 and b2) and a2[0] == b2[0]
    pre2 = sim_prefixo(a2, b2) if anc2 else 0.0
    if not (ancorado and pre >= cfg.sim_prefixo) and anc2 and pre2 >= cfg.sim_prefixo and len(a2) < len(b2):
        ancorado, pre = True, pre2
        a, b = a2, b2

    # A e o comeco de B: tentativa interrompida e refeita
    if len(a) < len(b) and ancorado and pre >= cfg.sim_prefixo:
        fim_coberto = a[-1] in b[: len(a) + 3]
        if inc_a or fim_coberto or pre >= 0.9:
            return "CORTA_A", f"tentativa interrompida, refeita em #{B['id']}", pre
        if pre >= cfg.sim_media:
            return "DUVIDOSO", f"começa igual a #{B['id']} mas termina diferente", pre

    # mesma frase dita de novo
    if full >= cfg.sim_alta:
        mesmo_fim = a[-1] == b[-1] or a[-1] in b[-3:]
        if (not inc_b) and (inc_a or mesmo_fim):
            return "CORTA_A", f"repetição; fica a última versão completa (#{B['id']})", full
        if inc_b and not inc_a and len(b) <= len(a):
            return "CORTA_B", f"tentativa interrompida depois da versão completa #{A['id']}", full
        if inc_a and inc_b:
            return "CORTA_A", f"repetição de tentativa interrompida; segue em #{B['id']}", full
        return "DUVIDOSO", f"duas versões completas parecidas com #{B['id']}, finais diferentes", full

    # A inteira esta dentro de B (B e uma versao maior)
    if len(a) >= 2 and len(b) > len(a) and contencao(a, b) >= 0.85:
        return "CORTA_A", f"conteúdo repetido dentro de #{B['id']}", contencao(a, b)

    # B so repete o FINAL de A ("...e vende como se fosse dele?" | "vende como se fosse dele.")
    if len(b) >= 2 and len(b) < len(a) and contencao(b, a[-(len(b) + 3):]) >= 0.85:
        return "CORTA_B", f"repete o final de #{A['id']}", contencao(b, a[-(len(b) + 3):])

    # meio-termo
    if (ancorado and pre >= cfg.sim_media) or full >= cfg.sim_media \
            or (len(b) >= 3 and contencao(b, a) >= 0.8) or (len(a) >= 3 and contencao(a, b) >= 0.7):
        return "DUVIDOSO", "semelhança média ({:.2f})".format(max(full, pre)), max(full, pre)
    return None, "", s


def corte_de_cauda(A: dict, B: dict, cfg: Config) -> int:
    """Se o FIM de A e um falso inicio do comeco de B ("... e hoje eu vou" | "hoje eu quero"),
    devolve quantas palavras finais de A cortar (0 = nada)."""
    wa = vivas(A)
    a, b = [tok(w) for w in wa], nucleo([tok(w) for w in vivas(B)])
    if len(a) < 3 or not b:
        return 0
    for n in range(min(12, len(a) - 1), 1, -1):
        cauda = nucleo(a[-n:])
        if len(cauda) < 2 or cauda[0] != b[0]:
            continue
        pre = sim_prefixo(cauda, b)
        inc = incompleta(wa[-n:])
        limiar = 0.65 if inc else 0.75
        if pre >= limiar and (cauda[-1] in b[: len(cauda) + 3] or inc):
            return n
    return 0


def ancorado_em(P: dict, B: dict) -> bool:
    p, b = nucleo([tok(w) for w in vivas(P)]), nucleo([tok(w) for w in vivas(B)])
    return bool(p and b and p[0] == b[0])


def camada4(trechos: list[dict], cfg: Config) -> None:
    for tr in trechos:
        tr.setdefault("decisao", "MANTER")
        tr.setdefault("motivo", "")
        tr["grupo"] = None
        cortes_internos(tr, cfg)

    # trechos que sao so hesitacao
    for tr in trechos:
        vv = vivas(tr)
        if tr["palavras"] and vv and all(eh_hesitacao(w, sozinho=True) for w in vv):
            tr["decisao"], tr["motivo"] = "CORTAR", "hesitação isolada"
        elif tr["palavras"] and not vv:
            tr["decisao"], tr["motivo"] = "CORTAR", "só hesitação"

    pai = {tr["id"]: tr["id"] for tr in trechos}

    def raiz(x):
        while pai[x] != x:
            pai[x] = pai[pai[x]]
            x = pai[x]
        return x

    def unir(x, y):
        pai[raiz(x)] = raiz(y)

    def anexa(X, campo, txt):
        X[campo] = (X[campo] + "; " if X[campo] else "") + txt

    for tr in trechos:
        tr.setdefault("alertas", [])
        ws = tr["palavras"]
        # contagem regressiva no comeco ("3, 2, 1, entao...") sai sempre
        n = 0
        while n < len(ws) and re.fullmatch(r"\d+", tok(ws[n]) or "x"):
            n += 1
        if n >= 2:
            for w in ws[:n]:
                w["corte"] = "fala de bastidor (contagem regressiva)"
        texto = " ".join(tok(w) for w in vivas(tr))
        if BASTIDOR_FORTE.search(texto) and len(vivas(tr)) <= BASTIDOR_MAX_PALAVRAS:
            tr["decisao"], tr["motivo"] = "CORTAR", "fala de bastidor (comentário sobre a gravação)"
        elif BASTIDOR.search(texto) or re.search(r"\b\d+\s+\d+\b", texto):
            tr["alertas"].append("possível fala de bastidor (comentário de gravação) — verifique")

    ativos: list[dict] = []
    for B in trechos:
        if B["decisao"] == "CORTAR" or not vivas(B):
            continue
        # compara com os anteriores ativos, do mais proximo para o mais distante
        k = len(ativos) - 1
        olhados = 0
        pulados: list[dict] = []   # trechos curtos sem relacao "atravessados" na busca
        while k >= 0 and olhados < cfg.janela_trechos:
            A = ativos[k]
            if B["ini"] - A["fim"] > cfg.janela_s:
                break
            olhados += 1
            acao, motivo, forca = relacao(A, B, cfg)
            if pulados and not (acao == "CORTA_A" and forca >= 0.8):
                if acao is None and len(vivas(A)) <= 4 and len(pulados) < 3:
                    pulados.append(A)
                    k -= 1
                    continue
                break  # depois de pular trechos, so aceita relacao forte
            # vizinho imediato sem corte inteiro: o FIM dele pode ser um falso inicio de B
            if acao in (None, "DUVIDOSO") and not pulados:
                n = corte_de_cauda(A, B, cfg)
                if n:
                    for w in vivas(A)[-n:]:
                        w["corte"] = f"falso início, refeito em #{B['id']}"
                    unir(A["id"], B["id"])
                    break
            if acao == "CORTA_A":
                A["decisao"], A["motivo"] = "CORTAR", motivo
                unir(A["id"], B["id"])
                ativos.pop(k)
                k -= 1
                for P in pulados:  # trechos curtos que ficaram no meio da regravacao
                    if ancorado_em(P, B):
                        P["decisao"], P["motivo"] = "CORTAR", f"falso início, refeito em #{B['id']}"
                        unir(P["id"], B["id"])
                        ativos[:] = [x for x in ativos if x is not P]
                    elif len(vivas(P)) <= 1 and P["fim"] - P["ini"] < cfg.fragmento_max:
                        P["decisao"], P["motivo"] = "CORTAR", \
                            f"fragmento solto no meio de uma regravação (#{A['id']} → #{B['id']})"
                        unir(P["id"], B["id"])
                        ativos[:] = [x for x in ativos if x is not P]
                    else:
                        P["alertas"].append(f"trecho curto solto no meio de uma regravação (#{A['id']} → #{B['id']})")
                pulados = []
                k = len([x for x in ativos if x["id"] < A["id"]]) - 1
                continue  # segue olhando para tras: pode ser uma cadeia de tentativas
            if acao == "CORTA_B":
                B["decisao"], B["motivo"] = "CORTAR", motivo
                unir(A["id"], B["id"])
                break
            if acao == "DUVIDOSO":
                for X, Y in ((A, B), (B, A)):
                    if X["decisao"] != "CORTAR":
                        X["decisao"] = "DUVIDOSO"
                        anexa(X, "motivo", f"{motivo} com #{Y['id']}")
                unir(A["id"], B["id"])
                break
            # sem relacao: se A e curto, pula e continua procurando uma tentativa anterior
            if len(vivas(A)) <= 4 and len(pulados) < 3:
                pulados.append(A)
                k -= 1
                continue
            break
        if B["decisao"] != "CORTAR":
            ativos.append(B)

    # numera grupos que tem mais de um membro
    membros: dict[int, list[int]] = {}
    for tr in trechos:
        membros.setdefault(raiz(tr["id"]), []).append(tr["id"])
    n = 0
    for r, ids in sorted(membros.items(), key=lambda kv: min(kv[1])):
        if len(ids) > 1:
            n += 1
            for tr in trechos:
                if tr["id"] in ids:
                    tr["grupo"] = n

    # trecho sem palavra nenhuma (depois da camada 3)
    for tr in trechos:
        if not tr["palavras"]:
            if tr["fim"] - tr["ini"] < cfg.ruido_max:
                tr["decisao"], tr["motivo"] = "CORTAR", "ruído/respiração curta (sem palavras)"
            else:
                tr["decisao"], tr["motivo"] = "DUVIDOSO", "fala detectada sem transcrição"


# --------------------------------------------------------------------------------------
# Camada 4b: revisão editorial (feita pelo Claude lendo a transcrição, como um editor)
# --------------------------------------------------------------------------------------
def aplicar_revisao(trechos: list[dict], caminho: Path) -> dict:
    """Aplica as decisões de revisao.json por cima da camada 4.

    Formato (ids são os números # da tabela; índices de palavras começam em 0, faixas inclusivas):
      {"cortar": [ids], "manter": [ids],
       "cortar_palavras": {"id": [[i, j], ...]}, "manter_palavras": {"id": [[i, j], ...]},
       "motivos": {"id": "fala de bastidor — conversa com a equipe"}}
    """
    rev = json.loads(caminho.read_text(encoding="utf-8"))
    por_id = {t["id"]: t for t in trechos}
    motivos = {int(k): str(v) for k, v in rev.get("motivos", {}).items()}
    feito = {"cortar": 0, "manter": 0, "palavras_cortadas": 0, "palavras_mantidas": 0, "ignorados": []}

    def pega(i):
        t = por_id.get(int(i))
        if t is None:
            feito["ignorados"].append(i)
        return t

    for i in rev.get("manter", []):
        t = pega(i)
        if t:
            t["decisao"] = "MANTER"
            t["motivo"] = "revisão: " + motivos.get(int(i), "mantido pelo editor")
            feito["manter"] += 1
    for i in rev.get("cortar", []):
        t = pega(i)
        if t:
            t["decisao"] = "CORTAR"
            t["motivo"] = "revisão: " + motivos.get(int(i), "repetição (cortado pelo editor)")
            feito["cortar"] += 1
    for campo, cortar in (("manter_palavras", False), ("cortar_palavras", True)):
        for i, faixas in rev.get(campo, {}).items():
            t = pega(i)
            if not t:
                continue
            for a, b in faixas:
                for w in t["palavras"][int(a):int(b) + 1]:
                    if cortar:
                        w["corte"] = "revisão: " + motivos.get(int(i), "repetição interna (cortado pelo editor)")
                        feito["palavras_cortadas"] += 1
                    elif w.pop("corte", None):
                        feito["palavras_mantidas"] += 1
    for t in trechos:  # trecho mantido sem nenhuma palavra viva vira corte
        if t["decisao"] != "CORTAR" and t["palavras"] and not vivas(t):
            t["decisao"], t["motivo"] = "CORTAR", "revisão: todas as palavras cortadas"
    feito["duvidosos_restantes"] = [t["id"] for t in trechos if t["decisao"] == "DUVIDOSO"]
    return feito


def escrever_trechos_revisao(caminho: Path, trechos: list[dict]) -> None:
    """Lista compacta para a revisão editorial: cada trecho com as palavras numeradas."""
    linhas = ["# Trechos para a revisão editorial", "",
              "Formato: #id [início–fim] DECISÃO (motivo) · grupo. Palavras numeradas a partir de 0;",
              "~~riscada~~ = já cortada pelo script.", ""]
    for t in trechos:
        ws = " ".join((f"~~{k}:{w['texto']}~~" if w.get("corte") else f"{k}:{w['texto']}")
                      for k, w in enumerate(t["palavras"]))
        g = f" · grupo {t['grupo']}" if t.get("grupo") else ""
        m = f" ({t['motivo']})" if t.get("motivo") else ""
        linhas.append(f"#{t['id']} [{fmt_t(t['ini'])}–{fmt_t(t['fim'])}] {t['decisao']}{m}{g}")
        linhas.append(f"    {ws or '(sem palavras)'}")
    caminho.write_text("\n".join(linhas) + "\n", encoding="utf-8")


# --------------------------------------------------------------------------------------
# Camada 5: montar os trechos mantidos e cortar pausas
# --------------------------------------------------------------------------------------
def ini_ef(w: dict) -> float:
    """Inicio efetivo do som da palavra (alinhamento, ou o comeco do trecho no VAD se for antes)."""
    return w.get("a_ini_ef", w["a_ini"])


def _quadros_entre(lo: float, hi: float, fps: float) -> list[int]:
    return list(range(int(math.ceil(lo * fps - 1e-6)), int(math.floor(hi * fps + 1e-6)) + 1))


def ponto_saida(en: Energia, L: dict, N: dict | None, cfg: Config, pausa: bool = False):
    """Quadro onde a fala mantida TERMINA, depois da palavra L (N = palavra seguinte no original).
    So aceita quadros em silencio (energia <= limiar + emenda_db), entre o fim do som de L e o
    comeco de N. Antes de um corte: o primeiro silencio depois de L e, dentro de 80 ms, o ponto
    mais baixo (leva o fim da palavra inteiro, sem levar a respiracao da tentativa cortada).
    Antes de uma pausa cortada: o silencio mais perto de --protecao-fim depois de L.
    Devolve (quadro, limpa, dB)."""
    fps, thr = cfg.fps, en.limiar + cfg.emenda_db
    lo = L["a_fim"] + 0.02
    hi = lo + 0.5
    if N is not None:
        hi = min(hi, ini_ef(N) - 0.03)
    ks = _quadros_entre(lo, hi, fps)
    if not ks:
        fim_n = ini_ef(N) if N is not None else L["a_fim"] + 0.1
        k = int(round((L["a_fim"] + fim_n) / 2 * fps))
        d = en.janela(k / fps)
        return k, d <= thr, d
    vals = [en.janela(k / fps) for k in ks]
    quietos = [i for i, v in enumerate(vals) if v <= thr]
    if not quietos:
        i = int(np.argmin(vals))
        return ks[i], False, vals[i]
    if pausa:
        alvo = L["a_fim"] + cfg.protecao_fim
        i = min(quietos, key=lambda i: abs(ks[i] / fps - alvo))
    else:
        lim = ks[quietos[0]] / fps + 0.08
        i = min((i for i in quietos if ks[i] / fps <= lim + 1e-6), key=lambda i: vals[i])
    return ks[i], True, vals[i]


def fim_do_som(en: Energia, t0: float, thr: float, lim: float = 0.5) -> float:
    """Primeiro instante depois de t0 em que a energia cai para o silencio."""
    i = max(0, int(t0 / 0.005))
    j = min(len(en.db5) - 1, int((t0 + lim) / 0.005))
    for k in range(i, j + 1):
        if en.db5[k] <= thr:
            return k * 0.005 + 0.005
    return t0 + lim


def inicio_do_som(en: Energia, t1: float, thr: float, lim: float = 0.5) -> float:
    """Andando para tras a partir de t1, o ultimo instante ainda em silencio (onde a fala comeca)."""
    i = min(len(en.db5) - 1, int(t1 / 0.005))
    for k in range(i, max(-1, i - int(lim / 0.005)), -1):
        if en.db5[k] <= thr:
            return k * 0.005 + 0.005
    return t1 - lim


def ponto_pausa(en: Energia, lo: float, hi: float, alvo: float, cfg: Config):
    """Corte dentro de uma pausa: o quadro de silencio PROFUNDO (abaixo do limiar de voz) mais
    perto do alvo; se nao houver, o de silencio comum. Assim nao corta no meio da respiracao."""
    ks = _quadros_entre(lo, hi, cfg.fps)
    if not ks:
        return None
    vals = [en.janela(k / cfg.fps) for k in ks]
    for teto in (en.limiar, en.limiar + cfg.emenda_db):
        cand = [i for i, v in enumerate(vals) if v <= teto]
        if cand:
            i = min(cand, key=lambda i: abs(ks[i] / cfg.fps - alvo))
            return ks[i], True, vals[i]
    return None


def ponto_entrada(en: Energia, P: dict | None, R: dict, cfg: Config):
    """Quadro onde a fala mantida COMECA, antes da palavra R (P = palavra anterior no original).
    So aceita quadros em silencio depois que o som de P acabou; entre eles, o mais perto de
    --margem-inicio antes de R (a respiracao da frase que continua fica). Devolve (quadro, limpa, dB)."""
    fps, thr = cfg.fps, en.limiar + cfg.emenda_db
    hi = ini_ef(R) - 0.03
    lo = hi - 0.6
    if P is not None:
        lo = max(lo, P["a_fim"] + 0.02)
    ks = _quadros_entre(max(0.0, lo), hi, fps)
    if not ks:
        ini_p = P["a_fim"] if P is not None else ini_ef(R) - 0.1
        k = max(0, int(round((ini_p + ini_ef(R)) / 2 * fps)))
        d = en.janela(k / fps)
        return k, d <= thr, d
    vals = [en.janela(k / fps) for k in ks]
    quietos = [i for i, v in enumerate(vals) if v <= thr]
    if not quietos:
        i = int(np.argmin(vals))
        return ks[i], False, vals[i]
    onset = min(inicio_do_som(en, R["a_ini"], thr), ini_ef(R))
    alvo = onset - cfg.margem_inicio - 0.04
    i = min(quietos, key=lambda i: abs(ks[i] / fps - alvo))
    return ks[i], True, vals[i]


def camada5(trechos: list[dict], en: Energia, dur: float, cfg: Config):
    """Monta os pedacos mantidos. Cada emenda e escolhida no audio (quadro a quadro), nunca
    no meio de uma palavra. Se nao ha silencio entre a ultima palavra mantida e a cortada
    (palavras coladas), a emenda e MOVIDA para a pausa natural mais proxima dentro do trecho
    repetido; se nem assim houver, corta no ponto mais baixo e vira ALERTA."""
    fps = cfg.fps
    flat = []
    for tr in trechos:
        ws = tr["palavras"] or [{"texto": "", "inicio": tr["ini"], "fim": tr["fim"],
                                 "a_ini": tr["ini"], "a_fim": tr["fim"]}]
        for w in ws:
            w.setdefault("a_ini", w["inicio"])
            w.setdefault("a_fim", w["fim"])
            flat.append({"w": w, "tr": tr})
        # o VAD sabe onde a fala do trecho comeca; se o Whisper nao escreveu a primeira
        # palavrinha ("E como..."), a emenda precisa comecar antes dela tambem
        ws[0]["a_ini_ef"] = round(min(ws[0]["a_ini"], tr["ini"] + 0.03), 3)
    n = len(flat)

    def W(i):
        return flat[i]["w"]

    def fica(i):
        return flat[i]["tr"]["decisao"] != "CORTAR" and not flat[i]["w"].get("corte")

    # --- 1) emenda no respiro: mover emendas coladas para uma pausa natural -------------
    movidas = []
    p = 0
    while p < n - 1:
        if not (fica(p) and not fica(p + 1)):
            p += 1
            continue
        q = p + 1
        while q < n and not fica(q):
            q += 1
        if q >= n:
            break
        e0 = ponto_saida(en, W(p), W(p + 1), cfg)
        s0 = ponto_entrada(en, W(q - 1), W(q), cfg)
        if not (e0[1] and s0[1]):
            movida = False
            m = 1
            while (p + m < q and q + m < n
                   and flat[p + m]["tr"] is flat[p]["tr"] and flat[p + m]["tr"]["decisao"] != "CORTAR"
                   and fica(q + m - 1) and fica(q + m)
                   and tok(W(p + m)) and tok(W(p + m)) == tok(W(q + m - 1))):
                e = ponto_saida(en, W(p + m), W(p + m + 1), cfg)
                s = ponto_entrada(en, W(q + m - 1), W(q + m), cfg)
                if e[1] and s[1]:
                    txt = " ".join(W(p + i)["texto"] for i in range(1, m + 1))
                    for i in range(1, m + 1):
                        W(p + i).pop("corte", None)
                        W(q + i - 1)["corte"] = f"repetição — emenda movida para a pausa (fica «{txt}» da 1ª vez)"
                    movidas.append({"t": W(p)["a_fim"], "antes": W(p)["texto"], "palavras": txt,
                                    "trecho_a": flat[p]["tr"]["id"], "trecho_b": flat[q]["tr"]["id"]})
                    movida = True
                    break
                m += 1
            # repeticao CURTA (1-2 palavras) dentro do mesmo trecho, sem silencio para emendar:
            # na duvida, manter. Um corte colado estraga mais do que uma palavra repetida.
            curta = (q - p - 1 <= 2 and all(flat[i]["tr"] is flat[p]["tr"] for i in range(p + 1, q + 1))
                     and all("bastidor" not in (W(i).get("corte") or "") for i in range(p + 1, q)))
            if not movida and curta:
                txt = " ".join(W(i)["texto"] for i in range(p + 1, q))
                for i in range(p + 1, q):
                    W(i).pop("corte", None)
                flat[p]["tr"].setdefault("alertas", []).append(
                    f"repetição curta «{txt}» NÃO cortada: palavras coladas, sem silêncio para emendar — ouça")
        p = q

    # --- 2) pedacos mantidos, com emendas escolhidas no audio --------------------------
    segs = []  # [kS, kE, info_entrada, info_saida]
    i = 0
    while i < n:
        if not fica(i):
            i += 1
            continue
        P = W(i - 1) if i > 0 else None
        kS, okS, dS = ponto_entrada(en, P, W(i), cfg)
        ent = {"ok": okS, "db": dS, "antes": P["texto"] if P else "", "palavra": W(i)["texto"],
               "tipo": "corte" if P is not None else "início", "w": W(i)}
        j = i
        while j + 1 < n and fica(j + 1):
            L, R = W(j), W(j + 1)
            # pausa: mede onde o som de L acaba e onde o de R comeca; se o silencio passa de
            # --pausa-max, fica ~0,3 s (protecao-fim depois + margem antes), em silencio profundo
            thr = en.limiar + cfg.emenda_db
            t_fim = fim_do_som(en, L["a_fim"] + 0.02, thr)
            t_on = min(inicio_do_som(en, R["a_ini"], thr), ini_ef(R))
            if t_on - t_fim > cfg.pausa_max:
                pe = ponto_pausa(en, t_fim, t_on - 0.1, t_fim + cfg.protecao_fim, cfg)
                ps = ponto_pausa(en, (pe[0] / fps if pe else t_fim) + 0.05, t_on - 0.02,
                                 t_on - cfg.margem_inicio - 0.04, cfg)
                kE, okE, dE = pe if pe else ponto_saida(en, L, R, cfg, pausa=True)
                kS2, okS2, dS2 = ps if ps else ponto_entrada(en, L, R, cfg)
                if (kS2 - kE) / fps > 0.05:
                    segs.append([kS, kE, ent, {"ok": okE, "db": dE, "palavra": L["texto"], "depois": R["texto"],
                                               "tipo": "pausa", "w": L}])
                    kS = kS2
                    ent = {"ok": okS2, "db": dS2, "antes": L["texto"], "palavra": R["texto"], "tipo": "pausa",
                           "w": R}
            j += 1
        L = W(j)
        N = W(j + 1) if j + 1 < n else None
        if N is None:
            kE = int(math.ceil((L["a_fim"] + cfg.protecao_fim) * fps))
            sai = {"ok": True, "db": en.janela(min(kE / fps, dur)), "palavra": L["texto"], "depois": "",
                   "tipo": "fim", "w": L}
        else:
            kE, okE, dE = ponto_saida(en, L, N, cfg)
            sai = {"ok": okE, "db": dE, "palavra": L["texto"], "depois": N["texto"], "tipo": "corte", "w": L}
        segs.append([kS, kE, ent, sai])
        i = j + 1

    fmax = int(math.floor(dur * fps))
    q: list[list[int]] = []
    infos: list[list[dict]] = []
    for kS, kE, ent, sai in segs:
        kS, kE = max(0, kS), min(kE, fmax)
        if kE <= kS:
            continue
        if q and kS <= q[-1][1]:
            q[-1][1] = max(q[-1][1], kE)
            infos[-1][1] = sai
        else:
            q.append([kS, kE])
            infos.append([ent, sai])

    # emendas (entre pedacos consecutivos), em tempo do original
    emendas = []
    acc = 0
    for a in range(len(q) - 1):
        sai, ent = infos[a][1], infos[a + 1][0]
        acc += q[a][1] - q[a][0]
        emendas.append({"n": a + 1, "t_seq": acc / fps, "fim_src": q[a][1] / fps, "ini_src": q[a + 1][0] / fps,
                        "palavra_antes": sai["palavra"], "cortado_depois": sai["depois"],
                        "cortado_antes": ent["antes"], "palavra_depois": ent["palavra"],
                        "ok_saida": sai["ok"], "db_saida": round(sai["db"], 1),
                        "ok_entrada": ent["ok"], "db_entrada": round(ent["db"], 1),
                        "tipo": "pausa" if sai["tipo"] == "pausa" and ent["tipo"] == "pausa" else "corte"})

    # contabilidade do que saiu
    nucleos_cortados = [(x["w"]["a_ini"], x["w"]["a_fim"], categoria(x["w"].get("corte") or x["tr"]["motivo"]))
                        for x in flat if not (x["tr"]["decisao"] != "CORTAR" and not x["w"].get("corte"))]
    removidos = []
    cursor = 0.0
    for fa, fb in q:
        a = fa / fps
        if a - cursor > 0.001:
            removidos.append((cursor, a))
        cursor = fb / fps
    if dur - cursor > 0.001:
        removidos.append((cursor, dur))
    seg_por_cat: dict[str, float] = {}
    pausas = 0
    for a, b in removidos:
        cats = {c for x, y, c in nucleos_cortados if min(b, y) - max(a, x) > 0.005}
        if not cats:
            pausas += 1
            seg_por_cat["pausa"] = seg_por_cat.get("pausa", 0.0) + (b - a)
        else:
            c = sorted(cats)[0]
            seg_por_cat[c] = seg_por_cat.get(c, 0.0) + (b - a)
    return q, removidos, pausas, seg_por_cat, emendas, movidas, infos


def categoria(motivo: str) -> str:
    m = motivo.lower()
    if "bastidor" in m:
        return "fala de bastidor"
    if "hesita" in m:
        return "hesitação"
    if "ruído" in m:
        return "ruído"
    if "interna" in m:
        return "repetição interna"
    if "falso" in m or "interrompida" in m or "fragmento" in m:
        return "tentativa interrompida"
    if "reformula" in m:
        return "reformulação"
    return "repetição"


# --------------------------------------------------------------------------------------
# Saidas
# --------------------------------------------------------------------------------------
def renderizar_wav(audio: np.ndarray, sr: int, quadros, fps: float, caminho: Path, fade: float):
    nf = max(1, int(fade * sr))
    rampa = np.linspace(0.0, 1.0, nf, dtype=np.float32)[:, None]
    partes = []
    for fa, fb in quadros:
        s = audio[int(round(fa / fps * sr)): int(round(fb / fps * sr))].copy()
        if len(s) > 2 * nf:
            s[:nf] *= rampa
            s[-nf:] *= rampa[::-1]
        partes.append(s)
    y = np.concatenate(partes) if partes else np.zeros((1, audio.shape[1]), np.float32)
    pcm = (np.clip(y, -1, 1) * 32767).astype("<i2")
    with wave.open(str(caminho), "wb") as wf:
        wf.setnchannels(audio.shape[1])
        wf.setsampwidth(2)
        wf.setframerate(sr)
        wf.writeframes(pcm.tobytes())
    return len(y) / sr


VOGAIS = set("aeiouáéíóúâêôãõàüy")


def inicio_ultima_silaba(w: dict) -> float:
    """Instante (no original) em que comeca a ultima silaba da palavra, pelas letras alinhadas.
    "baixa" -> "xa"; "dele" -> "le"; "outra" -> "tra"; "aqui" -> "qui". Sem letras: ~0,18 s antes do fim."""
    letras = w.get("a_letras")
    if not letras:
        return max(w["a_ini"], w["a_fim"] - 0.18)
    cs = [c for c, _ in letras]
    i = len(cs) - 1
    while i >= 0 and cs[i] not in VOGAIS:     # consoantes finais ("s" de "nas")
        i -= 1
    if i < 0:
        return letras[0][1]
    qu = lambda k: k - 1 >= 0 and cs[k] == "u" and cs[k - 1] in "qg"  # "qu"/"gu": o u e da consoante
    # ditongo decrescente ("ai", "ei", "ou", "ui"): a vogal de antes fica na mesma silaba.
    # Encontro crescente ("ia" de "criar") costuma ser hiato: a ultima silaba e so "ar".
    if cs[i] in "iuy" and i - 1 >= 0 and cs[i - 1] in VOGAIS and not qu(i - 1):
        i -= 1
    s = i
    if s - 1 >= 0 and qu(s - 1):                 # "qui", "gue"
        s -= 2
    elif s - 1 >= 0 and cs[s - 1] not in VOGAIS:  # consoante que abre a silaba
        s -= 1
        if s - 1 >= 0 and cs[s - 1] not in VOGAIS and cs[s] in "lrh":  # "tr", "pl", "ch", "lh", "nh"
            s -= 1
    return letras[s][1]


def montar_jcut(quadros, infos, cfg: Config):
    """Encavalar: a fala seguinte comeca quando a ULTIMA SILABA da anterior esta comecando.
    As falas alternam entre A1 e A2. No video (se houver), a imagem da fala seguinte so entra quando
    o audio da anterior acaba (J-cut de verdade: o som chega antes da imagem, sempre sincronizado).
    Nao duplica audio: cada trecho do original aparece uma vez so."""
    fps = cfg.fps
    clips = []
    for a, (fa, fb) in enumerate(quadros):
        if a == 0:
            ini, ov = 0, 0
        else:
            P = clips[-1]
            fim_p = P["ini"] + (P["fb"] - P["fa"])
            Lw, Rw = infos[a - 1][1].get("w"), infos[a][0].get("w")
            ov = 0
            if Lw is not None and Rw is not None:
                silaba = inicio_ultima_silaba(Lw)          # no original
                resto_a = P["fb"] / fps - silaba            # da ultima silaba ate o fim do pedaco A
                fala_b = max(ini_ef(Rw), fa / fps) - fa / fps  # do comeco do pedaco B ate a fala
                ov = int(round(max(0.0, min(cfg.jcut_max, resto_a + fala_b)) * fps))
                ov = min(ov, P["fb"] - P["fa"] - 1, fb - fa - 1)
                # nunca encostar no pedaco de duas falas atras (mesma trilha)
                if len(clips) >= 2:
                    PP = clips[-2]
                    ov = min(ov, max(0, fim_p - (PP["ini"] + (PP["fb"] - PP["fa"]))))
                ov = max(0, ov)
            ini = fim_p - ov
        clips.append({"fa": fa, "fb": fb, "ini": ini, "ov": ov, "trilha": a % 2})
    total = max(c["ini"] + (c["fb"] - c["fa"]) for c in clips) if clips else 0
    audio = [[], []]
    video = []
    for a, c in enumerate(clips):
        fim = c["ini"] + (c["fb"] - c["fa"])
        audio[c["trilha"]].append((c["ini"], fim, c["fa"], c["fb"]))
        # imagem: entra quando o audio anterior acaba (pula o trecho encavalado)
        v_in = c["ov"] if a > 0 else 0
        video.append((c["ini"] + v_in, fim, c["fa"] + v_in, c["fb"]))
    # conferencia de audio duplicado e de sobreposicao
    fontes = sorted((c["fa"], c["fb"]) for c in clips)
    duplicado = any(fontes[k][1] > fontes[k + 1][0] for k in range(len(fontes) - 1))
    mesma_trilha = any(x[1] > y[0] for lst in audio for x, y in zip(lst, lst[1:]))
    encav = [c["ov"] / fps for c in clips[1:]]
    checagem = {"audio_duplicado": duplicado, "sobreposicao_mesma_trilha": mesma_trilha,
                "encavalados": sum(1 for x in encav if x > 0),
                "encaixe_medio_s": round(float(np.mean(encav)), 3) if encav else 0.0,
                "encaixe_max_s": round(float(max(encav)), 3) if encav else 0.0}
    return {"video": video, "audio": audio, "total": total, "clips": clips}, checagem


def renderizar_wav_jcut(audio: np.ndarray, sr: int, montagem, fps: float, caminho: Path, fade: float):
    """Mixa as duas trilhas do J-cut num wav para ouvir."""
    nf = max(1, int(fade * sr))
    rampa = np.linspace(0.0, 1.0, nf, dtype=np.float32)[:, None]
    y = np.zeros((int(round(montagem["total"] / fps * sr)) + 1, audio.shape[1]), np.float32)
    for c in montagem["clips"]:
        s = audio[int(round(c["fa"] / fps * sr)): int(round(c["fb"] / fps * sr))].copy()
        if len(s) > 2 * nf:
            s[:nf] *= rampa
            s[-nf:] *= rampa[::-1]
        p = int(round(c["ini"] / fps * sr))
        y[p: p + len(s)] += s[: len(y) - p]
    pcm = (np.clip(y, -1, 1) * 32767).astype("<i2")
    with wave.open(str(caminho), "wb") as wf:
        wf.setnchannels(audio.shape[1])
        wf.setsampwidth(2)
        wf.setframerate(sr)
        wf.writeframes(pcm.tobytes())
    return len(y) / sr


def escrever_xml(caminho: Path, fonte: Path, info: dict, quadros, cfg: Config, marcadores, nome: str,
                 faixas: dict | None = None):
    """faixas (opcional, J-cut): {"video": [(ini_seq, fim_seq, in, out)], "audio": [[...], [...]], "total"}.
    Sem faixas: um pedaco depois do outro numa trilha so."""
    fps = cfg.fps
    tb = int(round(fps))
    ntsc = "TRUE" if abs(fps - round(fps)) > 0.001 else "FALSE"
    rate = f"<rate><timebase>{tb}</timebase><ntsc>{ntsc}</ntsc></rate>"
    dur_arq = int(math.floor(info["duracao"] * fps))
    url = "file://localhost/" + quote(str(fonte.resolve()).replace("\\", "/"), safe="/")
    canais = info["canais"]
    video = info.get("video")
    larg = (video or {}).get("largura") or 1920
    alt = (video or {}).get("altura") or 1080

    media_arq = (f"<audio><samplecharacteristics><depth>16</depth><samplerate>{info['sr']}"
                 f"</samplerate></samplecharacteristics><channelcount>{canais}</channelcount></audio>")
    if video:
        media_arq = (f"<video><samplecharacteristics>{rate}<width>{larg}</width><height>{alt}</height>"
                     f"</samplecharacteristics></video>") + media_arq
    arq_def = (f'<file id="file-1"><name>{escape(fonte.name)}</name><pathurl>{escape(url)}</pathurl>'
               f"{rate}<duration>{dur_arq}</duration><media>{media_arq}</media></file>")

    if faixas:
        pos_v, pos_a, total = faixas["video"], faixas["audio"], faixas["total"]
    else:
        seq = 0
        pos = []
        for fa, fb in quadros:
            pos.append((seq, seq + (fb - fa), fa, fb))
            seq += fb - fa
        total = seq
        pos_v, pos_a = pos, [pos]

    def clip(cid, s, e, i, o, tipo, idx, primeiro, rotulo):
        f = arq_def if primeiro else '<file id="file-1"/>'
        lab = f"<labels><label2>{rotulo}</label2></labels>" if rotulo else ""
        return (f'<clipitem id="{cid}"><masterclipid>masterclip-1</masterclipid>'
                f"<name>{escape(fonte.name)}</name><enabled>TRUE</enabled><duration>{dur_arq}</duration>"
                f"{rate}<start>{s}</start><end>{e}</end><in>{i}</in><out>{o}</out>{f}"
                f"<sourcetrack><mediatype>{tipo}</mediatype><trackindex>{idx}</trackindex></sourcetrack>"
                f"{lab}</clipitem>")

    def rotulo_de(fa, fb):
        return "Rose" if any(m.get("duvidoso") and fa <= m["src_q"] < fb for m in marcadores) else ""

    primeiro = True
    trilhas_v = ""
    if video:
        itens = []
        for n, (s, e, i, o) in enumerate(pos_v, 1):
            itens.append(clip(f"clipitem-v{n}", s, e, i, o, "video", 1, primeiro, rotulo_de(i, o)))
            primeiro = False
        trilhas_v = f"<track>{''.join(itens)}</track>"
    trilhas_a = ""
    for t_alt, lista in enumerate(pos_a):
        for ch in range(1, canais + 1):
            itens = []
            for n, (s, e, i, o) in enumerate(lista, 1):
                itens.append(clip(f"clipitem-a{t_alt}-{ch}-{n}", s, e, i, o, "audio", ch, primeiro, rotulo_de(i, o)))
                primeiro = False
            trilhas_a += f"<track>{''.join(itens)}</track>"

    marks = ""
    for m in marcadores:
        marks += (f"<marker><name>{escape(m['nome'])}</name><comment>{escape(m['comentario'])}</comment>"
                  f"<in>{m['seq_q']}</in><out>-1</out></marker>")

    xml = (
        '<?xml version="1.0" encoding="UTF-8"?>\n<!DOCTYPE xmeml>\n<xmeml version="4">'
        f'<sequence id="sequence-1"><name>{escape(nome)}</name><duration>{total}</duration>{rate}'
        f"<timecode>{rate}<string>00:00:00:00</string><frame>0</frame><displayformat>NDF</displayformat></timecode>"
        "<media>"
        f"<video><format><samplecharacteristics>{rate}<width>{larg}</width><height>{alt}</height>"
        f"<pixelaspectratio>square</pixelaspectratio></samplecharacteristics></format>{trilhas_v}</video>"
        f"<audio><numOutputChannels>2</numOutputChannels><format><samplecharacteristics><depth>16</depth>"
        f"<samplerate>48000</samplerate></samplecharacteristics></format>{trilhas_a}</audio>"
        f"</media>{marks}</sequence></xmeml>\n"
    )
    caminho.write_text(xml, encoding="utf-8")
    return total


def desenhar_emendas(audio16, en: Energia, trechos, emendas, cfg: Config, pasta: Path, por_pagina: int = 6):
    """Uma imagem por grupo de emendas: forma de onda + energia (dB) + palavras, dos dois lados
    de cada corte. Linha azul = corte; vermelho claro = o que saiu; tracejado laranja = limite
    de silencio. Serve para conferir de olho, como na timeline do Premiere."""
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except Exception:  # noqa: BLE001
        log("    (matplotlib não instalado: sem imagens das emendas)")
        return []
    for velho in pasta.glob("emendas-*.png"):
        velho.unlink()
    palavras = [(w, tr) for tr in trechos for w in tr["palavras"]]
    thr = en.limiar + cfg.emenda_db
    dur = len(audio16) / SR
    arquivos = []
    for pg in range(0, len(emendas), por_pagina):
        bloco = emendas[pg: pg + por_pagina]
        fig, axs = plt.subplots(len(bloco), 2, figsize=(16, 2.4 * len(bloco)), squeeze=False)
        for r, e in enumerate(bloco):
            for c, lado in enumerate(("saida", "entrada")):
                ax = axs[r][c]
                t = e["fim_src"] if lado == "saida" else e["ini_src"]
                a, b = (t - 0.9, t + 0.4) if lado == "saida" else (t - 0.4, t + 0.9)
                a, b = max(0.0, a), min(dur, b)
                x = audio16[int(a * SR): int(b * SR)]
                tt = a + np.arange(len(x)) / SR
                st = max(1, len(x) // 5000)
                ax.plot(tt[::st], x[::st], lw=0.5, color="#2a8a5a")
                if lado == "saida":
                    ax.axvspan(t, b, color="#e53935", alpha=0.12)
                else:
                    ax.axvspan(a, t, color="#e53935", alpha=0.12)
                ax.axvline(t, color="#1e40af", lw=1.6)
                ax.set_xlim(a, b)
                ax.set_ylim(-1, 1)
                ax.set_yticks([])
                ax.tick_params(labelsize=7)
                ax2 = ax.twinx()
                i0, i1 = int(a / 0.005), min(len(en.db5), int(b / 0.005))
                ax2.plot(np.arange(i0, i1) * 0.005 + 0.005, en.db5[i0:i1], lw=0.7, color="#555")
                ax2.axhline(thr, color="#f59e0b", lw=0.8, ls="--")
                ax2.set_ylim(-80, 0)
                ax2.set_yticks([])
                for w, tr in palavras:
                    if w["a_fim"] < a or w["a_ini"] > b or not w["texto"]:
                        continue
                    cortada = tr["decisao"] == "CORTAR" or w.get("corte")
                    ax.text(max(a, w["a_ini"]), 0.8, w["texto"], fontsize=8,
                            color="#c62828" if cortada else "#111")
                ok = e["ok_saida"] if lado == "saida" else e["ok_entrada"]
                db = e["db_saida"] if lado == "saida" else e["db_entrada"]
                if lado == "saida":
                    tit = f"#{e['n']} · {fmt_t(e['t_seq'])} no decupado · sai depois de «{e['palavra_antes']}»"
                else:
                    tit = f"entra em «{e['palavra_depois']}» ({fmt_t(t)} no original)"
                ax.set_title(f"{tit} · {db:.0f} dB · {'silêncio' if ok else 'COLADA'}", fontsize=9, loc="left",
                             color="#111" if ok else "#c62828")
        plt.tight_layout()
        arq = pasta / f"emendas-{pg // por_pagina + 1}.png"
        fig.savefig(arq, dpi=72)
        plt.close(fig)
        arquivos.append(arq)
    return arquivos


def texto_trecho_md(tr: dict) -> str:
    partes = []
    for w in tr["palavras"]:
        t = w["texto"].replace("|", "/")
        partes.append(f"~~{t}~~" if w.get("corte") else t)
    return " ".join(partes) if partes else "*(sem palavras)*"


def escrever_decisoes(caminho: Path, trechos, resumo: dict):
    L = []
    L.append(f"# Decupagem — {resumo['arquivo']}\n")
    L.append(f"- Duração antes: **{fmt_t(resumo['dur_antes'])}** ({resumo['dur_antes']:.1f} s)")
    L.append(f"- Duração depois: **{fmt_t(resumo['dur_depois'])}** ({resumo['dur_depois']:.1f} s)")
    L.append(f"- Trechos de fala: {len(trechos)} · MANTER {resumo['n_manter']} · "
             f"CORTAR {resumo['n_cortar']} · DUVIDOSO {resumo['n_duvidoso']}")
    L.append("- Cortes por tipo: " + ", ".join(f"{k} {v}" for k, v in resumo["cortes_tipo"].items()))
    L.append("- Tempo removido por tipo: " + ", ".join(f"{k} {v:.1f} s" for k, v in resumo["seg_tipo"].items()))
    L.append(f"- Modelo: {resumo['modelo']} em {resumo['device']} · transcrição {resumo['t_transc']:.1f} s\n")
    L.append("Legenda: ~~riscado~~ = palavra cortada dentro de um trecho mantido. "
             "Grupo = tentativas que o método considerou a mesma frase.\n")
    if resumo["n_duvidoso"]:
        L.append("## Duvidosos (para você escolher)\n")
        for tr in trechos:
            if tr["decisao"] == "DUVIDOSO":
                L.append(f"- **#{tr['id']}** {fmt_t(tr['ini'])} (grupo {tr['grupo'] or '-'}): "
                         f"{texto_trecho_md(tr)} — {tr['motivo']}")
        L.append("\nNo Premiere, cada duvidoso tem um marcador na sequência e o clipe recebe o rótulo Rose.\n")
    alertas = [tr for tr in trechos if tr.get("alertas") and tr["decisao"] != "CORTAR"]
    if alertas:
        L.append("## Alertas (mantidos, mas vale ouvir)\n")
        for tr in alertas:
            L.append(f"- **#{tr['id']}** {fmt_t(tr['ini'])}: {texto_trecho_md(tr)} — {'; '.join(tr['alertas'])}")
        L.append("\nNo Premiere eles também têm marcador (\"ALERTA\").\n")
    ems = resumo.get("emendas") or []
    if ems:
        col = [e for e in ems if not (e["ok_saida"] and e["ok_entrada"])]
        L.append("## Emendas\n")
        L.append(f"- {len(ems)} emendas · **{len(ems) - len(col)} em silêncio** · {len(col)} coladas "
                 f"(sem silêncio entre as palavras: marcador \"ALERTA emenda colada\" no Premiere)")
        al = resumo.get("alinhamento") or {}
        L.append(f"- Alinhamento letra a letra: {al.get('estado', '-')} "
                 f"({al.get('alinhadas', 0)}/{al.get('palavras', 0)} palavras)")
        for mv in resumo.get("movidas") or []:
            L.append(f"- Emenda movida para a pausa natural: «{mv['antes']} **{mv['palavras']}**» ficou da 1ª "
                     f"tentativa (#{mv['trecho_a']}); a fala continua na #{mv['trecho_b']}")
        for e in col:
            L.append(f"- ⚠️ {fmt_t(e['t_seq'])} no decupado ({fmt_t(e['fim_src'])} no original): "
                     f"«{e['palavra_antes']}» | «{e['palavra_depois']}»")
        L.append("\nImagens de cada emenda: `emendas-1.png`, `emendas-2.png`…\n")
    L.append("## Todos os trechos\n")
    L.append("| # | Início | Fim | Grupo | Texto | Decisão | Motivo |")
    L.append("|---|---|---|---|---|---|---|")
    for tr in trechos:
        dec = tr["decisao"]
        mot = tr["motivo"]
        internos = sorted({w["corte"] for w in tr["palavras"] if w.get("corte")})
        if internos and dec != "CORTAR":
            mot = (mot + "; " if mot else "") + "corte interno: " + ", ".join(internos)
        if tr.get("suspeitas"):
            mot = (mot + "; " if mot else "") + "suspeito: " + ", ".join(sorted({s["tipo"] for s in tr["suspeitas"]}))
        dec_md = {"MANTER": "MANTER", "CORTAR": "**CORTAR**", "DUVIDOSO": "⚠️ **DUVIDOSO**"}[dec]
        L.append(f"| {tr['id']} | {fmt_t(tr['ini'])} | {fmt_t(tr['fim'])} | {tr['grupo'] or ''} | "
                 f"{texto_trecho_md(tr)} | {dec_md} | {mot.replace('|', '/')} |")
    caminho.write_text("\n".join(L) + "\n", encoding="utf-8")


# --------------------------------------------------------------------------------------
# Pipeline de transcricao (camadas 1-3), reaproveitado na conferencia
# --------------------------------------------------------------------------------------
def transcrever_tudo(model, audio16, cfg: Config):
    en = Energia(audio16)
    t0 = time.time()
    trechos = camada1_trechos(audio16, cfg)
    t_vad = time.time() - t0
    t0 = time.time()
    for n, tr in enumerate(trechos, 1):
        tr["id"] = n
        tr["palavras"] = transcrever_regiao(model, audio16, tr["ini"], tr["fim"], cfg)
    t_c2 = time.time() - t0
    t0 = time.time()
    cont3 = camada3(model, audio16, en, trechos, cfg)
    t_c3 = time.time() - t0
    return trechos, en, cont3, {"vad": t_vad, "camada2": t_c2, "camada3": t_c3}


def mapear_para_fonte(t: float, quadros, fps) -> float:
    seq = 0.0
    for fa, fb in quadros:
        d = (fb - fa) / fps
        if t <= seq + d:
            return fa / fps + (t - seq)
        seq += d
    return quadros[-1][1] / fps if quadros else t


def conferir(model, ffmpeg, wav: Path, trechos_fonte, quadros, cfg: Config, saida_md: Path, emendas_src=None):
    audio16 = decodificar(ffmpeg, str(wav), SR, 1)[:, 0]
    t0 = time.time()
    tr2, _, cont3, _ = transcrever_tudo(model, audio16, cfg)
    t_conf = time.time() - t0
    # roda o detector de repeticoes de novo, sem aplicar nada
    camada4(tr2, cfg)
    duvidosos_fonte = [(t["ini"], t["fim"]) for t in trechos_fonte if t["decisao"] == "DUVIDOSO"]

    def eh_duvidoso(t_seq):
        s = mapear_para_fonte(t_seq, quadros, cfg.fps)
        return any(a - 0.3 <= s <= b + 0.3 for a, b in duvidosos_fonte)

    achados = []
    for t in tr2:
        internos = [w for w in t["palavras"] if w.get("corte") and "hesita" not in w["corte"]]
        hes = [w for w in t["palavras"] if w.get("corte") and "hesita" in w["corte"]]
        if t["decisao"] in ("CORTAR", "DUVIDOSO") and t["palavras"]:
            if "hesita" in t["motivo"]:
                tipo = "hesitação"
            else:
                tipo = "repetição/tentativa"
            achados.append({"t": t["ini"], "tipo": tipo, "texto": " ".join(w["texto"] for w in t["palavras"]),
                            "motivo": t["motivo"], "decisao": t["decisao"],
                            "esperado": eh_duvidoso(t["ini"])})
        for w in internos:
            achados.append({"t": w["inicio"], "tipo": "repetição interna", "texto": texto_trecho_md(t),
                            "motivo": w["corte"], "decisao": "detectado", "esperado": eh_duvidoso(w["inicio"])})
        for w in hes:
            achados.append({"t": w["inicio"], "tipo": "hesitação", "texto": texto_trecho_md(t),
                            "motivo": w["corte"], "decisao": "detectado", "esperado": eh_duvidoso(w["inicio"])})

    # checagem global: sequencia de 4+ palavras que aparece duas vezes em menos de 20 s
    toks = [(tok(w), w["inicio"]) for t in tr2 for w in t["palavras"] if tok(w)]
    ngr = {}
    repet = []
    n = 4
    for i in range(len(toks) - n + 1):
        chave = tuple(x for x, _ in toks[i: i + n])
        ti = toks[i][1]
        if chave in ngr and ti - ngr[chave] < 20:
            repet.append((ngr[chave], ti, " ".join(chave)))
        ngr[chave] = ti

    texto_esperado = [tok(w) for t in trechos_fonte if t["decisao"] != "CORTAR" for w in vivas(t)]
    texto_obtido = [x for x, _ in toks]
    fidelidade = SequenceMatcher(None, texto_esperado, texto_obtido, autojunk=False).ratio()

    inesperados = [a for a in achados if not a["esperado"]]
    rep_inesperadas = [r for r in repet if not (eh_duvidoso(r[0]) or eh_duvidoso(r[1]))]

    # (b) nenhuma ideia sumiu: palavras de conteudo de tudo que foi cortado precisam existir no que ficou
    mantidas = {tok(w) for t in trechos_fonte if t["decisao"] != "CORTAR" for w in vivas(t)}
    perdidas = []
    revisao_sem_rep = []
    for t in trechos_fonte:
        blocos = []
        if "bastidor" in t["motivo"]:
            continue  # fala de bastidor sai de proposito: nao e "ideia perdida"
        # corte decidido na revisão editorial: não reprova (b), vai para uma lista "confira"
        destino = revisao_sem_rep if t["motivo"].startswith("revisão:") else perdidas
        if t["decisao"] == "CORTAR" and t["palavras"]:
            blocos.append((destino, t["palavras"]))
        elif t["decisao"] != "CORTAR":
            run, run_dest = [], perdidas
            for w in t["palavras"] + [{"texto": "", "corte": None}]:
                c = w.get("corte") or ""
                if c and "bastidor" not in c:
                    d = revisao_sem_rep if c.startswith("revisão:") else perdidas
                    if run and d is not run_dest:
                        blocos.append((run_dest, run))
                        run = []
                    run.append(w)
                    run_dest = d
                elif run:
                    blocos.append((run_dest, run))
                    run = []
        for lista, ws in blocos:
            cont = [tok(w) for w in ws if len(tok(w)) >= 4 and tok(w) not in FUNCIONAIS_FIM]
            if not cont:
                continue
            # aceita grafia diferente (Mateus/Matheus); falha se mais da metade das palavras sumiu
            falt = [c for c in cont if c not in mantidas
                    and not any(SequenceMatcher(None, c, m).ratio() >= 0.8 for m in mantidas)]
            if len(falt) / len(cont) > 0.5:
                lista.append({"trecho": t["id"], "t": ws[0]["inicio"],
                              "texto": " ".join(w["texto"] for w in ws), "faltando": falt})

    # (c) fim de palavra comido: retranscreve o 1,2 s antes de cada emenda, sozinho
    palavras_fonte = sorted([w for t in trechos_fonte if t["decisao"] != "CORTAR" for w in vivas(t)],
                            key=lambda w: w["inicio"])
    emendas = []
    seq = 0.0
    for fa, fb in quadros[:-1]:
        seq += (fb - fa) / cfg.fps
        fim_src = fb / cfg.fps
        cand = [w for w in palavras_fonte if w["fim"] <= fim_src + 0.02 and w["inicio"] >= fa / cfg.fps - 0.05]
        if not cand:
            continue
        esp = cand[-1]
        e = normalizar(esp["texto"])
        E = "".join(normalizar(w["texto"]) for w in cand[-2:])

        def confere(janela):
            got = transcrever_regiao(model, audio16, max(0.0, seq - janela), seq, cfg, sem_prompt=True,
                                     pad_real=0.0, temperatura=(0.0,))
            ult = [normalizar(w["texto"]) for w in got[-2:]]
            O = "".join(ult)
            L_ = min(len(E), len(O))
            ok = bool(ult) and (ult[-1] == e or SequenceMatcher(None, ult[-1], e).ratio() >= 0.8
                                or (len(e) >= 3 and e in O) or (L_ >= 3 and SequenceMatcher(None, E[-L_:], O[-L_:]).ratio() >= 0.8))
            return ok, " ".join(w["texto"] for w in got[-2:]) or "(nada)"

        ok, obtido = confere(1.2)
        if not ok:  # segunda chance com mais contexto
            ok, obtido = confere(2.5)
        # palavra de 1-2 letras ("ó", "é") nao da para conferir assim
        estado = "não verificável" if len(e) <= 2 else ("ok" if ok else "falhou")
        emendas.append({"t_seq": seq, "t_src": fim_src, "esperado": esp["texto"],
                        "obtido": obtido, "ok": ok, "estado": estado})
    emendas_falhas = [x for x in emendas if x["estado"] == "falhou"]

    # (d) duvidosos: os pares precisam ser duas versoes completas e diferentes
    por_id = {t["id"]: t for t in trechos_fonte}
    duv_check = []
    for t in trechos_fonte:
        if t["decisao"] != "DUVIDOSO":
            continue
        if not t["palavras"]:
            duv_check.append({"id": t["id"], "t": t["ini"], "ok": True, "nota": "fala sem transcrição (ouvir)"})
            continue
        pares = [int(x) for x in re.findall(r"#(\d+)", t["motivo"]) if int(x) in por_id]
        notas, ok = [], True
        for pid in pares:
            o = por_id[pid]
            a, b = [tok(w) for w in vivas(t)], [tok(w) for w in vivas(o)]
            s = sim(a, b)
            if incompleta(vivas(t)) or incompleta(vivas(o)):
                ok = False
                notas.append(f"com #{pid}: uma das versões está incompleta")
            elif s >= cfg.sim_alta:
                ok = False
                notas.append(f"com #{pid}: quase iguais ({s:.2f}) — deveria ter cortado")
            else:
                notas.append(f"com #{pid}: completas e diferentes ({s:.2f})")
        duv_check.append({"id": t["id"], "t": t["ini"], "ok": ok, "nota": "; ".join(notas)})
    duv_falhas = [x for x in duv_check if not x["ok"]]

    # (e) emendas em silencio: nenhum corte no meio do som de uma palavra (medido no original)
    emendas_src = emendas_src or []
    coladas = [e for e in emendas_src if not (e["ok_saida"] and e["ok_entrada"])]

    crit = {
        "a": len(inesperados) == 0 and len(rep_inesperadas) == 0,
        "b": len(perdidas) == 0,
        "c": len(emendas_falhas) == 0,
        "d": len(duv_falhas) == 0,
        "e": len(coladas) == 0,
    }

    def v(x):
        return "✅ passou" if x else "❌ falhou"

    L = ["# Conferência — retranscrição do audio_decupado.wav\n",
         "## Critérios\n",
         f"- **(a) nenhuma repetição sobrou:** {v(crit['a'])} — {len(inesperados)} repetições inesperadas, "
         f"{len(rep_inesperadas)} sequências de 4 palavras repetidas fora de duvidosos",
         f"- **(b) nenhuma ideia sumiu:** {v(crit['b'])} — {len(perdidas)} trechos cortados com palavras que não "
         "aparecem em nenhum lugar do que ficou",
         f"- **(c) nenhum fim de palavra comido:** {v(crit['c'])} — "
         f"{sum(x['estado'] == 'ok' for x in emendas)}/{len(emendas)} emendas com a última palavra reconhecida "
         f"inteira, {sum(x['estado'] == 'não verificável' for x in emendas)} não verificáveis (palavra de 1-2 letras)",
         f"- **(d) duvidosos são mesmo duvidosos:** {v(crit['d'])} — {len(duv_check) - len(duv_falhas)}/{len(duv_check)}",
         f"- **(e) toda emenda cai em silêncio:** {v(crit['e'])} — {len(emendas_src) - len(coladas)}/{len(emendas_src)} "
         "emendas sem cortar som de palavra (nem o fim da última, nem o começo da próxima)\n"]
    if emendas_src:
        L.append("### (e) emendas medidas no áudio\n")
        L.append("Energia no ponto de corte (±10 ms). Silêncio = abaixo de "
                 f"limiar de voz + {cfg.emenda_db:.0f} dB. Imagens em `emendas-N.png`.\n")
        L.append("| # | Decupado | Sai depois de | dB | Entra em | dB | Tipo | OK? |")
        L.append("|---|---|---|---|---|---|---|---|")
        for e in emendas_src:
            ok = e["ok_saida"] and e["ok_entrada"]
            L.append(f"| {e['n']} | {fmt_t(e['t_seq'])} | {e['palavra_antes']} ({fmt_t(e['fim_src'])}) | "
                     f"{e['db_saida']:.0f} | {e['palavra_depois']} ({fmt_t(e['ini_src'])}) | {e['db_entrada']:.0f} | "
                     f"{e['tipo']} | {'sim' if ok else '**COLADA**'} |")
        L.append("")
    if perdidas:
        L.append("### (b) possíveis ideias perdidas\n")
        for p in perdidas:
            L.append(f"- #{p['trecho']} {fmt_t(p['t'])}: \"{p['texto']}\" — palavras ausentes: {', '.join(p['faltando'])}")
        L.append("")
    L.append("### (c) emendas\n")
    L.append("| Emenda (decupado) | Original | Última palavra esperada | Retranscrito (1,2 s antes) | OK? |")
    L.append("|---|---|---|---|---|")
    for x in emendas:
        L.append(f"| {fmt_t(x['t_seq'])} | {fmt_t(x['t_src'])} | {x['esperado']} | {x['obtido']} | "
                 f"{ {'ok': 'sim', 'falhou': '**NÃO**'}.get(x['estado'], x['estado'])} |")
    L.append("\n### (d) duvidosos\n")
    for x in duv_check:
        L.append(f"- #{x['id']} {fmt_t(x['t'])}: {'ok' if x['ok'] else '**problema**'} — {x['nota']}")
    L += ["\n## Detalhes\n",
          f"- Trechos retranscritos: {len(tr2)} · tempo: {t_conf:.1f} s",
         f"- Fidelidade texto esperado × retranscrito: {fidelidade:.1%}",
         f"- Suspeitos da camada 3 no resultado: {cont3}",
         f"- Repetições/hesitações detectadas no resultado: {len(achados)} "
         f"({len(achados) - len(inesperados)} são duvidosos mantidos de propósito, "
         f"{len(inesperados)} inesperadas)",
         f"- Sequências de 4 palavras repetidas em < 20 s: {len(repet)} "
         f"({len(rep_inesperadas)} fora de duvidosos)\n"]
    if achados:
        L.append("| Tempo no decupado | Tempo no original | Tipo | Esperado? | Texto | Motivo |")
        L.append("|---|---|---|---|---|---|")
        for a in sorted(achados, key=lambda x: x["t"]):
            L.append(f"| {fmt_t(a['t'])} | {fmt_t(mapear_para_fonte(a['t'], quadros, cfg.fps))} | {a['tipo']} | "
                     f"{'sim (duvidoso)' if a['esperado'] else '**não**'} | {a['texto'].replace('|', '/')} | "
                     f"{a['motivo'].replace('|', '/')} |")
    if repet:
        L.append("\n## Sequências repetidas\n")
        for a, b, txt in repet:
            L.append(f"- \"{txt}\" em {fmt_t(a)} e {fmt_t(b)} (original {fmt_t(mapear_para_fonte(a, quadros, cfg.fps))}"
                     f" / {fmt_t(mapear_para_fonte(b, quadros, cfg.fps))})"
                     + (" — duvidoso" if eh_duvidoso(a) or eh_duvidoso(b) else ""))
    L.append("\n## Texto retranscrito\n")
    for t in tr2:
        L.append(f"- {fmt_t(t['ini'])} {' '.join(w['texto'] for w in t['palavras']) or '(sem palavras)'}")
    saida_md.write_text("\n".join(L) + "\n", encoding="utf-8")
    return {"achados": len(achados), "inesperados": len(inesperados), "ngram_repetidos": len(repet),
            "ngram_inesperados": len(rep_inesperadas), "fidelidade": fidelidade, "tempo_s": time.time() - t0,
            "criterios": crit, "emendas": len(emendas), "emendas_falhas": emendas_falhas,
            "ideias_perdidas": perdidas, "duvidosos_check": duv_check,
            "revisao_sem_repeticao": revisao_sem_rep,
            "lista_inesperados": inesperados, "lista_ngram": rep_inesperadas}


# --------------------------------------------------------------------------------------
# Principal
# --------------------------------------------------------------------------------------
def main(argv=None):
    for s in (sys.stdout, sys.stderr):
        try:
            s.reconfigure(encoding="utf-8")
        except Exception:  # noqa: BLE001
            pass
    ap = argparse.ArgumentParser(description="Decupagem automática de fala em português.")
    ap.add_argument("entrada", nargs="?", help="arquivo de áudio ou vídeo (só leitura)")
    ap.add_argument("--saida", help="pasta de saída (padrão: pasta do arquivo)")
    ap.add_argument("--ajuda-parametros", action="store_true")
    d = Config()
    for campo, valor in asdict(d).items():
        if isinstance(valor, bool):
            continue
        ap.add_argument("--" + campo.replace("_", "-"), type=type(valor), default=valor)
    ap.add_argument("--sem-conferencia", action="store_true")
    ap.add_argument("--sem-alinhamento", action="store_true", help="não usa o alinhamento letra a letra")
    ap.add_argument("--sem-imagens", action="store_true", help="não gera emendas-N.png")
    ap.add_argument("--jcut", action="store_true",
                    help="também gera a versão encavalada (falas alternando A1/A2, a próxima entrando na "
                         "última sílaba da anterior): decupagem-jcut.xml e audio_jcut.wav")
    ap.add_argument("--reusar-transcricao", help="transcricao.json de uma rodada anterior (pula camadas 1-3)")
    ap.add_argument("--revisao", help="revisao.json com as decisões da revisão editorial (ver SKILL.md)")
    args = ap.parse_args(argv)
    if args.ajuda_parametros:
        print(AJUDA_PARAMETROS)
        return
    if not args.entrada:
        ap.error("informe o arquivo de entrada")
    cfg = Config(**{k: getattr(args, k) for k in asdict(d) if k != "conferir"})
    cfg.conferir = not args.sem_conferencia

    fonte = Path(args.entrada).resolve()
    saida = Path(args.saida).resolve() if args.saida else fonte.parent
    saida.mkdir(parents=True, exist_ok=True)
    ffmpeg, ffprobe = achar_exe("ffmpeg"), achar_exe("ffprobe")
    t_total = time.time()

    log(f"[0] Lendo {fonte.name}")
    info = sondar(ffprobe, str(fonte))
    log(f"    {info['duracao']:.1f} s · {info['codec']} {info['sr']} Hz · {info['canais']} canal(is)"
        f"{' · com vídeo' if info['video'] else ' · só áudio'}")
    audio16 = decodificar(ffmpeg, str(fonte), SR, 1)[:, 0]
    audio_full = decodificar(ffmpeg, str(fonte), info["sr"], info["canais"])
    dur = len(audio16) / SR

    log("[modelo] carregando")
    t0 = time.time()
    model, dev, ct = carregar_modelo(cfg)
    t_modelo = time.time() - t0

    if args.reusar_transcricao:
        log(f"[1-3] reaproveitando a transcrição de {args.reusar_transcricao}")
        old = json.loads(Path(args.reusar_transcricao).read_text(encoding="utf-8"))
        trechos = [{"id": t["id"], "ini": t["inicio"], "fim": t["fim"], "suspeitas": t.get("suspeitas", []),
                    "palavras": [{k: v for k, v in w.items() if k != "corte"} for w in t["palavras"]]}
                   for t in old["trechos"]]
        en, cont3 = Energia(audio16), old["suspeitos"]
        tempos = {k: old["tempos_s"][k] for k in ("vad", "camada2", "camada3")}
    else:
        log("[1-3] picotando (VAD), transcrevendo trecho a trecho e checando suspeitos")
        trechos, en, cont3, tempos = transcrever_tudo(model, audio16, cfg)
    t_transc = tempos["vad"] + tempos["camada2"] + tempos["camada3"]
    log(f"    {len(trechos)} trechos · VAD {tempos['vad']:.1f} s · transcrição {tempos['camada2']:.1f} s"
        f" · retranscrição de suspeitos {tempos['camada3']:.1f} s")
    log(f"    suspeitos: {cont3}")

    log("[2b] alinhamento fino (letra a letra)")
    alinh = alinhar_trechos(audio16, trechos, cfg, not args.sem_alinhamento)
    log(f"    {alinh['estado']} · {alinh['alinhadas']}/{alinh['palavras']} palavras · {alinh['tempo_s']} s")

    log("[4] agrupando repetições")
    camada4(trechos, cfg)
    revisao = None
    if args.revisao:
        revisao = aplicar_revisao(trechos, Path(args.revisao))
        log(f"[4b] revisão editorial: {revisao['cortar']} trechos cortados, {revisao['manter']} mantidos, "
            f"{revisao['palavras_cortadas']} palavras cortadas, {revisao['palavras_mantidas']} devolvidas"
            + (f" · ids ignorados: {revisao['ignorados']}" if revisao["ignorados"] else "")
            + (f" · duvidosos ainda sem decisão: {revisao['duvidosos_restantes']}"
               if revisao["duvidosos_restantes"] else ""))
    escrever_trechos_revisao(saida / "trechos-revisao.md", trechos)
    log("[5] montando cortes e pausas (emendas escolhidas no áudio)")
    quadros, removidos, n_pausas, seg_tipo, emendas, movidas, infos = camada5(trechos, en, dur, cfg)
    coladas = [e for e in emendas if not (e["ok_saida"] and e["ok_entrada"])]
    log(f"    {len(emendas)} emendas · {len(emendas) - len(coladas)} em silêncio · {len(coladas)} coladas"
        f" · {len(movidas)} movidas para a pausa natural")
    for mv in movidas:
        log(f"      → emenda movida: «{mv['antes']} {mv['palavras']}» fica da 1ª vez (#{mv['trecho_a']}),"
            f" continua em #{mv['trecho_b']}")
    for e in coladas:
        log(f"      ! emenda colada em {fmt_t(e['fim_src'])}: «{e['palavra_antes']}|{e['cortado_depois']}»"
            f" {e['db_saida']} dB / «{e['cortado_antes']}|{e['palavra_depois']}» {e['db_entrada']} dB")

    wav = saida / "audio_decupado.wav"
    dur_depois = renderizar_wav(audio_full, info["sr"], quadros, cfg.fps, wav, cfg.fade)

    # marcadores dos duvidosos no tempo da sequencia
    marcadores = []
    seq_ini = []
    acc = 0
    for fa, fb in quadros:
        seq_ini.append((fa, fb, acc))
        acc += fb - fa
    for tr in trechos:
        if tr["decisao"] == "CORTAR" or not (tr["decisao"] == "DUVIDOSO" or tr.get("alertas")):
            continue
        f = int(round(tr["ini"] * cfg.fps))
        for fa, fb, s in seq_ini:
            if fa <= f < fb or f < fa:
                if tr["decisao"] == "DUVIDOSO":
                    nome, coment = f"DUVIDOSO #{tr['id']} (grupo {tr['grupo'] or '-'})", tr["motivo"]
                else:
                    nome, coment = f"ALERTA #{tr['id']}", "; ".join(tr["alertas"])
                marcadores.append({"nome": nome, "duvidoso": tr["decisao"] == "DUVIDOSO",
                                   "comentario": f"{' '.join(w['texto'] for w in vivas(tr))} — {coment}",
                                   "seq_q": s + max(0, f - fa), "src_q": max(f, fa)})
                break
    # emenda sem silencio (palavras coladas): marcador exatamente no corte
    for e in emendas:
        if e["ok_saida"] and e["ok_entrada"]:
            continue
        f = int(round(e["fim_src"] * cfg.fps))
        for fa, fb, s in seq_ini:
            if fb == f:
                marcadores.append({"nome": "ALERTA emenda colada", "duvidoso": False,
                                   "comentario": f"«{e['palavra_antes']}» | «{e['palavra_depois']}» — não há silêncio "
                                                 "entre as palavras; cortei no ponto mais baixo. Ouça.",
                                   "seq_q": s + (fb - fa), "src_q": f})
                break
    # cada rodada vira uma sequencia NOVA, com data e hora no nome: nunca substitui nem mexe na
    # sequencia original nem numa versao anterior (da para comparar lado a lado)
    nome_seq = f"{fonte.stem} - decupado {time.strftime('%d-%m %Hh%M')}"
    escrever_xml(saida / "decupagem.xml", fonte, info, quadros, cfg, marcadores, nome_seq)

    jcut = None
    if args.jcut:
        montagem, jcut = montar_jcut(quadros, infos, cfg)
        # marcadores no tempo da sequencia encavalada
        marc_j = []
        for m in marcadores:
            for c in montagem["clips"]:
                if c["fa"] <= m["src_q"] <= c["fb"]:
                    marc_j.append({**m, "seq_q": c["ini"] + (m["src_q"] - c["fa"])})
                    break
        escrever_xml(saida / "decupagem-jcut.xml", fonte, info, quadros, cfg, marc_j,
                     f"{fonte.stem} - jcut {time.strftime('%d-%m %Hh%M')}", faixas=montagem)
        jcut["duracao_s"] = round(renderizar_wav_jcut(audio_full, info["sr"], montagem, cfg.fps,
                                                      saida / "audio_jcut.wav", cfg.fade), 2)
        log(f"[5b] J-cut: {jcut['encavalados']} falas encavaladas (média {jcut['encaixe_medio_s']} s,"
            f" máx {jcut['encaixe_max_s']} s) · duração {fmt_t(jcut['duracao_s'])} · "
            f"áudio duplicado: {'SIM — confira' if jcut['audio_duplicado'] else 'não'} · "
            f"sobreposição na mesma trilha: {'SIM — confira' if jcut['sobreposicao_mesma_trilha'] else 'não'}")
    imagens = [] if args.sem_imagens else desenhar_emendas(audio16, en, trechos, emendas, cfg, saida)
    if imagens:
        log(f"    imagens das emendas: {', '.join(p.name for p in imagens)}")

    cortes_tipo: dict[str, int] = {"pausa": n_pausas}
    for tr in trechos:
        if tr["decisao"] == "CORTAR":
            c = categoria(tr["motivo"])
            cortes_tipo[c] = cortes_tipo.get(c, 0) + 1
        else:
            ws = tr["palavras"]
            k = 0
            while k < len(ws):
                if ws[k].get("corte"):
                    c = categoria(ws[k]["corte"])
                    cortes_tipo[c] = cortes_tipo.get(c, 0) + 1
                    while k < len(ws) and ws[k].get("corte"):
                        k += 1
                else:
                    k += 1
    resumo = {
        "arquivo": fonte.name, "dur_antes": dur, "dur_depois": dur_depois,
        "n_manter": sum(t["decisao"] == "MANTER" for t in trechos),
        "n_cortar": sum(t["decisao"] == "CORTAR" for t in trechos),
        "n_duvidoso": sum(t["decisao"] == "DUVIDOSO" for t in trechos),
        "cortes_tipo": cortes_tipo, "seg_tipo": {k: round(v, 2) for k, v in seg_tipo.items()},
        "modelo": f"faster-whisper {cfg.modelo} ({ct})", "device": dev, "t_transc": t_transc,
        "alinhamento": alinh, "emendas": emendas, "movidas": movidas, "jcut": jcut,
        "revisao": revisao,
    }

    transc = {
        "arquivo": str(fonte), "duracao": round(dur, 3), "modelo": cfg.modelo, "device": dev,
        "compute_type": ct, "parametros": asdict(cfg),
        "tempos_s": {"carregar_modelo": round(t_modelo, 1), **{k: round(v, 1) for k, v in tempos.items()}},
        "suspeitos": cont3,
        "trechos": [{
            "id": t["id"], "inicio": round(t["ini"], 3), "fim": round(t["fim"], 3),
            "texto": " ".join(w["texto"] for w in t["palavras"]),
            "decisao": t["decisao"], "motivo": t["motivo"], "grupo": t["grupo"],
            "suspeitas": t.get("suspeitas", []),
            "palavras": [{k: v for k, v in w.items()} for w in t["palavras"]],
        } for t in trechos],
        "cortes_em_quadros": {"fps": cfg.fps, "mantidos": quadros},
    }
    (saida / "transcricao.json").write_text(json.dumps(transc, ensure_ascii=False, indent=2), encoding="utf-8")
    escrever_decisoes(saida / "decisoes.md", trechos, resumo)

    log(f"    antes {fmt_t(dur)} → depois {fmt_t(dur_depois)} · cortes {cortes_tipo} · "
        f"duvidosos {resumo['n_duvidoso']}")

    conf = None
    if cfg.conferir:
        log("[6] conferência: retranscrevendo o audio_decupado.wav")
        conf = conferir(model, ffmpeg, wav, trechos, quadros, cfg, saida / "conferencia.md", emendas)
        log(f"    fidelidade {conf['fidelidade']:.1%} · repetições restantes: {conf['achados']} "
            f"({conf['inesperados']} inesperadas) · 4-gramas repetidos fora de duvidosos: {conf['ngram_inesperados']}")
        for a in conf["lista_inesperados"]:
            log(f"      ! {fmt_t(a['t'])} {a['tipo']}: {a['texto']} ({a['motivo']})")
        for a, b, txt in conf["lista_ngram"]:
            log(f"      ! \"{txt}\" em {fmt_t(a)} e {fmt_t(b)}")
        log(f"    critérios: {conf['criterios']} · emendas {conf['emendas'] - len(conf['emendas_falhas'])}/{conf['emendas']}")
        for x in conf["emendas_falhas"]:
            log(f"      ! emenda {fmt_t(x['t_seq'])}: esperado '{x['esperado']}', ouvido '{x['obtido']}'")
        for p in conf["ideias_perdidas"]:
            log(f"      ! ideia perdida? #{p['trecho']} {p['texto']} (faltam {p['faltando']})")
        for p in conf["revisao_sem_repeticao"]:
            log(f"      · confira: cortado na revisão e sem outra versão no vídeo: #{p['trecho']} {p['texto']}")
        for x in conf["duvidosos_check"]:
            if not x["ok"]:
                log(f"      ! duvidoso #{x['id']}: {x['nota']}")

    resumo_json = {**resumo, "tempo_total_s": round(time.time() - t_total, 1),
                   "tempo_modelo_s": round(t_modelo, 1), "tempos_s": tempos, "suspeitos": cont3,
                   "conferencia": None if conf is None else {k: v for k, v in conf.items() if not k.startswith("lista")}}
    (saida / "resumo.json").write_text(json.dumps(resumo_json, ensure_ascii=False, indent=2), encoding="utf-8")
    log(f"[ok] tudo em {saida} ({resumo_json['tempo_total_s']} s no total)")


if __name__ == "__main__":
    main()
