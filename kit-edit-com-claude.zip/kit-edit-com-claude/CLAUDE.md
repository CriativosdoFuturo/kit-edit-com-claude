# Kit Edit com Claude Code / Criativos do Futuro: workspace guide

Turn a talking-head recording into an intentional edit using local HyperFrames
rendering, transcript-driven cuts, and reusable motion graphics.

## Runtime

This kit runs in Claude Code (Claude desktop app, Code tab, with this folder
selected). Skills live in `.claude/skills/`. Start with the `trombino` skill or
natural language; it routes to the needed editing and animation skills.
Model and permission choices belong to the user. Work locally unless the user
requests subagents.

## Regras do curso (sempre)

- Aprove a imagem estática antes de animar. Quando o aluno quiser aprovar antes de qualquer mudança, use o modo Plan.
- Separe os elementos (texto, ícones, fundos, cards) antes de animar.
- Artes que vão por cima do vídeo sempre com fundo transparente, com canal alpha de verdade (não fundo preto nem "chroma").
- Mantenha as artes fora das áreas da interface do Instagram/Reels (topo, legenda, botões da lateral direita e da parte de baixo).
- Nunca cubra o rosto nem os gestos do apresentador.
- Layout aprovado: uma arte acima e outra abaixo do apresentador.
- Depois de qualquer J-cut, confira se ficou áudio duplicado.
- Na decupagem, faça sempre a revisão editorial (skill trombino-decupagem-pt): de cada frase regravada fica a última versão completa, e a conversa de bastidor sai. Só mantenha duas versões quando forem ideias diferentes. Liste para o aluno as trocas, com o tempo, para ele mudar se quiser.
- Trabalhe sempre numa versão nova da sequência, preservando a anterior.
- Falas de bastidor ("tô começando a gravar", "bora lá", "3, 2, 1") saem.
- Nunca salve o projeto do editor sem o aluno pedir.
- Antes de importar algo no Premiere, confira qual projeto está ativo (o aluno pode ter outros projetos abertos).

## Start and route

Read `README.md` for installation and `docs/WORKFLOW.md` for a complete edit.
Use `trombino` first to establish the delivery target. Use `trombino-edit-video` for the HyperFrames editing path; verify a separate editor integration for native timeline work.
After installation and the eight-second test, start the first real edit in a new Claude Code session (the kit skills also work in sessions opened on other folders; projects stay in this folder's `video-projects/`). Do not carry dependency logs, broad tool discovery, or setup troubleshooting into a native-editor decoupage. Read docs/DECUPAGEM-SEGURA.md before transcript-driven editing through an editor MCP. The Premiere MCP is named `premiere_pro_trombino`.
For one stage, load the matching skill. All kit skills are named with the `trombino-` prefix (the main one is just `trombino`); when a kit text cites a skill by its short name, use the prefixed one:

| Need | Skill |
| --- | --- |
| Decupagem de fala em português (erros, tentativas, repetições, falas de bastidor, pausas) com XML para o Premiere | `trombino-decupagem-pt` |
| Reels, Shorts, and short advertisements | `trombino-short-form-edit` |
| Existing May Shorts example maintenance | `trombino-short-form-video` |
| New motion-graphics video from a brief | `trombino-make-a-video` |
| Website-inspired compositions | `trombino-website-to-hyperframes` |
| Full raw-video edit | `trombino-edit-video` |
| Silence removal, dentro do caminho de vídeo pronto pelo HyperFrames | `trombino-cut-silences` |
| Retakes, false starts, or stutters, dentro do caminho de vídeo pronto pelo HyperFrames | `trombino-cut-mistakes` |
| Narrative arc, persistent world, and visual callbacks | `trombino-video-storytelling` |
| Overlay beats, paper takeovers, and glass cards | `trombino-hyperframes-video-beats` |
| Select or extend styles and templates | `trombino-style-library` |
| HTML compositions and media timing | `trombino-hyperframes` |
| Preview, lint, and rendering | `trombino-hyperframes-cli` |
| Timeline animation | `trombino-gsap` |
| Install HyperFrames catalog blocks | `trombino-hyperframes-registry` |

Before a creative session read `MOTION_PHILOSOPHY.md` and the project's DESIGN.md.
The philosophy's fast sizzle pacing is a style reference. Give educational speech
room to breathe. The project brief controls pacing, palette, and typography.
Framework skill contracts override historical code recipes in the style guide.

## Workspace

Create a project with `npm run new-video -- my-video`. Keep source media, EDLs,
transcripts, compositions, and renders together under `video-projects/<slug>/`.
Run HyperFrames from that project's directory. The root `scripts/` utilities
accept paths from the working directory. `style-library/registry.json` indexes
cards; each style has a DESIGN.md, CSS tokens, and named text slots.
See `style-templates/README.md` for whole-scene templates.

Preserve raw files. Use a new output filename for each editing stage. Archive
obsolete work. Video projects, personal footage, transcripts, credentials, and
renders are gitignored. This beginner distribution omits the upstream branded projects and showcase media; new private projects stay ignored. Do not treat existing public examples as permission to add
new personal footage. Never print secrets or copy private media into library examples.

## Editing and timing

Before choosing a transcription, asset-generation, or voiceover service, read
`docs/TOOLS-AND-API-KEYS.md` and check the user's provider choice and local setup.
This course prefers a verified local transcription option when no paid service is requested. Never assume local Whisper is installed. Ask before choosing a paid provider. Normalize verified word timestamps for the cutting
tools. The included transcription script is ElevenLabs-only. Kie.ai is optional
and needs a configured integration and credits. Reuse existing transcripts and
assets; make any unapproved uploads or paid calls concrete before asking.

For speech cleanup in Portuguese aimed at an editor, use `trombino-decupagem-pt`. In the
HyperFrames finished-video path, cut silences first; use its edited video AND
retimed transcript for cut-mistakes.
Review each mistake in context. Intentional repetition is not a mistake. Record
the reviewed decisions before applying them. If no cuts are needed, preserve the
input or use an empty cuts list. Never mix original timestamps with edited footage.

Load the relevant skills before changing HTML. Root compositions use a visible
div with id, data-composition-id, data-start, duration, width, and height. Timed
elements carry data-start, data-duration, and data-track-index; same-track clips
must not overlap. Visible timed divs use class="clip"; videos do not.
Mute videos and use sibling audio for the mix. Animate a non-timed video wrapper.
Register one synchronous paused GSAP timeline per composition in window.__timelines
using its exact composition ID. Keep finite timelines and explicit durations.
HyperFrames owns media playback. Use deterministic animation and local assets.

## Verification and approvals

Run `node scripts/preflight.mjs <project>` and HyperFrames lint. For anchored
sub-compositions, run `node scripts/validate-beat-sync.mjs <project>`; each beat
needs data-anchor with an exact transcript phrase. Enter between 0.2 seconds after
and 1.8 seconds before that word. Inline timelines require manual timing review.

Review Studio before draft rendering. Review the encoded draft, extract and
inspect hero frames and transition boundaries, and listen to the audio joins.
Check cropped faces, overflow, black flashes, readable labels, clipping, and A/V
sync. Resolve problems before the final render. Save evidence in VERIFY.md.
Use a Range-capable preview server for MP4 scrubbing (for example `npx serve`).

Honor approvals already provided. When review approval is missing, prepare the
concrete preview or cut proposal first. Never claim a lint result proves visual
quality. Only publish or upload a finished video when the user authorizes it.
Automated browser checks must be headless, with Pointer Lock and cursor capture
disabled; synthetic input must remain inside the virtual browser.

For short-form edits, read `docs/SHORT-FORM.md` and use the plan and footage
validators. Structural checks supplement rendered video and audio review.
